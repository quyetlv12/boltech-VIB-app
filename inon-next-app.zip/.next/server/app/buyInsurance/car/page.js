(() => {
var exports = {};
exports.id = 715;
exports.ids = [715];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 9274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 7342:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/no-ssr-error.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 4053:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 2781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 1371:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "metadata": () => (/* binding */ metadata),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2315);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2333);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2885);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9505);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(683);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3269);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5746);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8208);
/* harmony import */ var next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7__);

    const tree = {
        children: [
        '',
        {
        children: [
        'buyInsurance',
        {
        children: [
        'car',
        {
        children: ['', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 1190, 23)), "F:\\INON\\inon-next-app\\app\\buyInsurance\\car\\page.tsx"]}]
      },
        {
          
        }
      ]
      },
        {
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 8514, 23)), "F:\\INON\\inon-next-app\\app\\layout.tsx"],
'head': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 447)), "F:\\INON\\inon-next-app\\app\\head.tsx"],
        }
      ]
      }.children;
    const metadata = [{
          type: 'layout',
          layer: 0,
          mod: () => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 8514, 23)),
          path: "F:\\INON\\inon-next-app\\app\\layout.tsx",
        },{
          type: 'page',
          layer: 2,
          mod: () => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 1190, 23)),
          path: "F:\\INON\\inon-next-app\\app\\buyInsurance\\car\\page.tsx",
        },];
    const pages = ["F:\\INON\\inon-next-app\\app\\buyInsurance\\car\\page.tsx"];

    
    
    
    

    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
  

/***/ }),

/***/ 2658:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9022))

/***/ }),

/***/ 1190:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ */ const { createProxy  } = __webpack_require__(4353);
module.exports = createProxy("F:\\INON\\inon-next-app\\app\\buyInsurance\\car\\page.tsx");


/***/ }),

/***/ 9022:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
// EXTERNAL MODULE: ./constants/index.ts + 9 modules
var constants = __webpack_require__(8451);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(9483);
// EXTERNAL MODULE: ./store/buyInsurance.ts
var buyInsurance = __webpack_require__(227);
;// CONCATENATED MODULE: ./assests/banner/banner-main.png
/* harmony default export */ const banner_main = ({"src":"/_next/static/media/banner-main.101b3cd1.png","height":570,"width":1242,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAIAAAA8r+mnAAAAV0lEQVR42hXGQQ5AMBBA0T9TEmFN4gaO4LpOZOsUQqJSTU3p4iVPbJk5D3wkCD6gA1EJpmSoul9JP5ESfic+ymuguAbX0o/Eiyzy3AqCZbQu2VZwGBn9ABNDIIvAcqpuAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":4});
// EXTERNAL MODULE: ./node_modules/react-redux/lib/index.js
var lib = __webpack_require__(1560);
;// CONCATENATED MODULE: ./components/BannerStep0.tsx








const BannerStep0 = ()=>{
    const step0data = (0,constants/* useAppSelector */.CG)(buyInsurance/* getStep0data */.fx);
    const dispatch = (0,lib.useDispatch)();
    const pathName = (0,navigation.usePathname)();
    (0,react_.useEffect)(()=>{
        // check local data deleted => get data step 0
        if ((0,constants/* isObjectEmpty */.nK)(step0data)) {
            const stepData = constants/* PRODUCTS.find */.bQ.find((_elt)=>_elt.link === pathName);
            dispatch((0,buyInsurance/* selectInsuraneBuy */.sl)(stepData));
        }
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "absolute text-xl top-[50%] text-[#fff] left-[5%]",
                        children: step0data.name
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex justify-end ",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: step0data?.logo,
                            className: "w-[30%] absolute top-[30%] right-[5%]",
                            alt: "banner main"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: banner_main,
                        className: "w-full",
                        alt: "banner main"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "font-medium text-[22px] px-[5%] mb-4",
                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "text-[15px]",
                    children: step0data.slogan
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "font-bold text-[22px] px-[5%]",
                children: "Quyền lợi bảo hiểm"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "text-[15px] px-[5%] mt-3 bg-[#fbf2ee] py-5",
                children: step0data.benefit && step0data.benefit.map((_elt, index)=>{
                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex mb-3 h-[50px]",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: `${index === 1 ? "w-[50px]" : "w-[35px]"} flex items-center`,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: _elt.icon !== undefined ? _elt.icon : "",
                                    alt: "image 1",
                                    className: `mb-5 mt-4`
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: `text-[16px] ml-5 h-[50px] flex items-center font-normal`,
                                children: _elt?.content
                            })
                        ]
                    }, index);
                })
            })
        ]
    });
};
/* harmony default export */ const components_BannerStep0 = (BannerStep0);

;// CONCATENATED MODULE: ./components/BuyInsuranceStep.tsx



const BuyInsuranceStep = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(components_BannerStep0, {});
};
/* harmony default export */ const components_BuyInsuranceStep = (BuyInsuranceStep);

// EXTERNAL MODULE: ./node_modules/react-currency-input-field/dist/index.js
var dist = __webpack_require__(1824);
var dist_default = /*#__PURE__*/__webpack_require__.n(dist);
// EXTERNAL MODULE: ./node_modules/styled-components/dist/styled-components.cjs.js
var styled_components_cjs = __webpack_require__(3103);
;// CONCATENATED MODULE: ./components/InputCpn.tsx






const InputStyled = styled_components_cjs/* default.div */.ZP.div`
  input {
    width: 100%;
    height: 70px;
    padding: 2%;
    border-radius: 10px;
    padding-top: 8%;
  }
  .placeholder__input {
    position: absolute;
    top: 10%;
    padding: 0 2%;
  }
`;
const CurrencyInputCpn = ({ value , placeholder  })=>{
    const inputStatus = (0,constants/* useAppSelector */.CG)(buyInsurance/* getInputStatus */.Rv);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(InputStyled, {
        className: `relative ${inputStatus ? "" : "hidden"} px-3`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "mb-3 font-semibold text-[20px]",
                children: "Nhập số tiền tr\xe1ch nhiệm"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "relative mt-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "placeholder__input text-[12px] text-[#9DA3AE]",
                        children: "Mức tr\xe1ch nhiệm BH tai nạn người ngồi"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((dist_default()), {
                        id: "input-number",
                        name: "input-name",
                        placeholder: placeholder,
                        defaultValue: value,
                        decimalsLimit: 2,
                        className: "shadow-lg",
                        onValueChange: (value, name)=>console.log(value, name),
                        autoFocus: true
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const InputCpn = (CurrencyInputCpn);

;// CONCATENATED MODULE: ./assests/arrow.png
/* harmony default export */ const arrow = ({"src":"/_next/static/media/arrow.c16615d4.png","height":14,"width":8,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAYAAAAx8TU7AAAAfElEQVR42mOYu2jdrzmL13UxQMHsJeuYGOYtXJMwd9Ha/0CJyQzIYN6CNc5QiRVggbmLN7AwAMH8Bav1gRLvgBJHGYAMkCCQ3iAENP/pnEVrjzNABNaIzF287hlQYC1YYM6iNZpzF699PGfx2s1wS+YCZYECZ+FOWrSWGQBKZT/rLEKVYQAAAABJRU5ErkJggg==","blurWidth":5,"blurHeight":8});
;// CONCATENATED MODULE: ./components/RowInfo.tsx






const RowInfo = ({ info  })=>{
    const inputStatus = (0,constants/* useAppSelector */.CG)(buyInsurance/* getInputStatus */.Rv);
    const dispath = (0,constants/* useAppDispatch */.TL)();
    const handleInputValue = (object)=>{
        dispath((0,buyInsurance/* turnOnInput */.Hx)(object));
        const input = document.querySelector("#input-number");
        if (input !== null) {
            input.setAttribute("autoFocus", "autoFocus");
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `${inputStatus ? "hidden" : "block"}`,
                children: info.map((_elt, index)=>{
                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex justify-between px-3 py-5 h-[50px] items-center bg-[#fff] shadow-[#F3F4F6]",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "w-3/4 text-[15px]",
                                children: _elt.content
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex items-center gap-3 w-1/4 justify-end",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        onClick: ()=>handleInputValue(_elt),
                                        children: "nhập"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: arrow,
                                        alt: "arrow"
                                    })
                                ]
                            })
                        ]
                    }, index);
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(InputCpn, {
                placeholder: "Nhập gi\xe1 trị",
                value: 20000000
            })
        ]
    });
};
/* harmony default export */ const components_RowInfo = (RowInfo);

;// CONCATENATED MODULE: ./components/Title.tsx




const Title = ({ title , subTitle , className , size ="22"  })=>{
    const inputStatus = (0,constants/* useAppSelector */.CG)(buyInsurance/* getInputStatus */.Rv);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `px-3 ${className} ${!inputStatus ? "" : "hidden"}`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: `font-bold text-[${size}px]`,
                children: title
            }),
            subTitle && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: `text-[#6C727F] text-[17px] font-normal`,
                children: subTitle
            })
        ]
    });
};
/* harmony default export */ const components_Title = (Title);

;// CONCATENATED MODULE: ./app/buyInsurance/car/step/utility.tsx

const KEY_SEATS = "seat";
const KEY_CAR_TYPE = "type";
const KEY_YEARR = "year";
const KEY_ADDONS = "addons";
const KEY_VALUE = "seat";
const KEY_RESPONSIBILITY = "responsibility";
const CUSTOM_FIELD = [
    {
        content: "Số ghế ngồi",
        key_form: KEY_SEATS,
        typeInput: constants/* INPUT_SELECT_TYPE */.s9
    },
    {
        content: "Loại xe",
        key_form: KEY_CAR_TYPE,
        typeInput: constants/* INPUT_SELECT_TYPE */.s9
    },
    {
        content: "Năm sản xuất",
        key_form: KEY_SEATS,
        typeInput: constants/* INPUT_SELECT_TYPE */.s9
    },
    {
        content: "Gi\xe1 trị xe",
        key_form: KEY_VALUE,
        typeInput: constants/* INPUT_SELECT_TYPE */.s9
    },
    {
        content: "Mức tr\xe1ch nhiệm BH tai nạn người ngồi",
        key_form: KEY_RESPONSIBILITY,
        typeInput: constants/* INPUT_NUMBER_TYPE */.OV
    },
    {
        content: "Điều khoản mở rộng",
        key_form: KEY_ADDONS,
        typeInput: constants/* INPUT_SELECT_TYPE */.s9
    }
];

;// CONCATENATED MODULE: ./assests/insurance/pjico-logo.png
/* harmony default export */ const pjico_logo = ({"src":"/_next/static/media/pjico-logo.99054145.png","height":40,"width":41,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA2klEQVR42i2NT0rDUBjE3308hpdw7RE8hKfQjehKwYWKi4IIdlEiFYN/IBVtrbU07/OZtH0NpH3fTJuks5hhhh+MISkASBJBwVVZMBRZMwBiKtsWHBzestVOGO6PsfI5SYpR1Ro4Oe/A7F1weHfK8mgXYVk2QGXeF9zZv8R394aMDZfjuD6FhgbQENiJh2D+RU7a9SMbiRnZqXz85nwbWES9CV8GGd/7KV77wvHfXIwfJWIfr5glEdKHM9qnFl2vCxtdc/r5LEYXuYT/H+rcQt0mZynVOwRXbU7WZNzpJWtezqcAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./components/PackageSelect.tsx






const PackageSelect = ()=>{
    const inputStatus = (0,constants/* useAppSelector */.CG)(buyInsurance/* getInputStatus */.Rv);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: `px-[5%] ${inputStatus ? "hidden" : ""}`,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "bg-[#fff] w-full rounded-md",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "border-b-[1px] border-[#F3F4F6] px-[20px] py-[10px] flex items-center gap-5",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: pjico_logo,
                            alt: "logo pjico",
                            width: 50
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "PJICO"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-[#F47920] font-semibold text-[15px]",
                                    children: "1,500,000 đ/năm"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "border-b-[1px] text-[15px] flex justify-between border-[#F3F4F6] px-[20px] py-[10px]",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: " text-[#4D5562] w-3/4",
                            children: "Bảo hiểm bắt buộc TNDS"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "font-medium w-1/4 text-right",
                            children: "Kh\xf4ng"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "border-b-[1px] text-[15px] flex justify-between border-[#F3F4F6] px-[20px] py-[10px]",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: " text-[#4D5562] w-3/4",
                            children: "Bảo hiểm tai nạn người ngồi tr\xean xe"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "font-medium w-1/4 text-right",
                            children: "Kh\xf4ng"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "border-b-[1px] text-[15px] flex justify-between border-[#F3F4F6] px-[20px] py-[10px]",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: " text-[#4D5562] w-3/4",
                            children: "Gi\xe1 trị bảo hiểm vật chất xe"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "font-medium w-1/4 text-right",
                            children: "Kh\xf4ng"
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const components_PackageSelect = (PackageSelect);

;// CONCATENATED MODULE: ./app/buyInsurance/car/step/step1.tsx





// import   from 'assests/arrow.png'

const Step1 = ()=>{
    const dispatch = (0,constants/* useAppDispatch */.TL)();
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "mb-3 py-5",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(components_Title, {
                    title: "Th\xf4ng tin chi tiết xe",
                    subTitle: "Thay đổi th\xf4ng tin để c\xf3 kết quả ph\xf9 hợp",
                    className: "mb-3"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(components_RowInfo, {
                    info: CUSTOM_FIELD
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(components_Title, {
                    title: "Kết quả g\xf3i bảo hiểm ph\xf9 hợp",
                    className: "mb-3 mt-3",
                    size: "16"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(components_PackageSelect, {})
            ]
        })
    });
};
/* harmony default export */ const step1 = (Step1);

;// CONCATENATED MODULE: ./app/buyInsurance/car/step/step2.tsx




const Step2 = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "mb-3 py-5",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(components_Title, {
                    title: "Xe \xf4t\xf4 được bảo hiểm",
                    subTitle: "Vui l\xf2ng điền th\xf4ng tin ch\xednh x\xe1c",
                    className: "mb-3"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(components_RowInfo, {
                    info: CUSTOM_FIELD
                })
            ]
        })
    });
};
/* harmony default export */ const step2 = (Step2);

;// CONCATENATED MODULE: ./app/buyInsurance/car/step/step3.tsx

const Step3 = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: "view step3"
    });
};
/* harmony default export */ const step3 = (Step3);

;// CONCATENATED MODULE: ./components/Button.tsx



function Button(props) {
    const inputStatus = (0,constants/* useAppSelector */.CG)(buyInsurance/* getInputStatus */.Rv);
    return /*#__PURE__*/ jsx_runtime_.jsx("button", {
        onClick: props.onClick,
        ...props,
        className: `py-2 px-4 text-600 text-[#fff] bg-brand-gradient rounded-[100px] ${props.className} ${inputStatus && !props.hiddenBtn ? "hidden" : ""}`,
        children: props.name
    });
}

;// CONCATENATED MODULE: ./components/Footer.tsx







const Footer = ()=>{
    const [textBtnFooter, setTextBtnFooter] = (0,react_.useState)("Button here");
    const dispatch = (0,constants/* useAppDispatch */.TL)();
    const step = (0,constants/* useAppSelector */.CG)(buyInsurance/* getStep */.TO);
    const inputStatus = (0,constants/* useAppSelector */.CG)(buyInsurance/* getInputStatus */.Rv);
    const pathName = (0,navigation.usePathname)();
    const handleNextStep = ()=>{
        dispatch((0,buyInsurance/* nextStep */.zF)());
    };
    const depenc = [
        pathName,
        step,
        inputStatus
    ];
    (0,react_.useEffect)(()=>{
        // check text in button
        if (step === 0 && !inputStatus) {
            setTextBtnFooter(constants/* BUY_ONLINE */.zp);
        } else if (step === 1 && !inputStatus) {
            setTextBtnFooter(constants/* SELECT_PACKAGE */.Bh);
        } else if (inputStatus) {
            setTextBtnFooter(constants/* APPLY */.zJ);
        } else if (step === 2) {
            setTextBtnFooter(constants/* COUNTINUE */.zE);
        } else if (step === 3 && !inputStatus) {
            setTextBtnFooter(constants/* BUY_NOW */.HV);
        }
    }, [
        depenc
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "w-full absolute bottom-0 py-[5px] footer__main",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex justify-center w-full px-[5%]",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Button, {
                        name: textBtnFooter,
                        className: "w-full",
                        hiddenBtn: true,
                        onClick: handleNextStep
                    }),
                    " "
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: `text-[${constants/* TEXT_FOOTER_COLOR */.hv}] text-[12px] text-center mt-3`,
                children: "Hotline: +84 244 4582 274"
            })
        ]
    });
};
/* harmony default export */ const components_Footer = (Footer);

;// CONCATENATED MODULE: ./app/buyInsurance/car/page.tsx









const BuyCarInsurance = ()=>{
    const step = (0,constants/* useAppSelector */.CG)(buyInsurance/* getStep */.TO);
    const dispatch = (0,constants/* useAppDispatch */.TL)();
    const renderSceen = ()=>{
        switch(step){
            case 0:
                return /*#__PURE__*/ jsx_runtime_.jsx(components_BuyInsuranceStep, {});
            case 1:
                return /*#__PURE__*/ jsx_runtime_.jsx(step1, {});
            case 2:
                return /*#__PURE__*/ jsx_runtime_.jsx(step2, {});
            case 3:
                return /*#__PURE__*/ jsx_runtime_.jsx(step3, {});
            default:
                break;
        }
    };
    (0,react_.useEffect)(()=>{
        dispatch((0,buyInsurance/* turnOffInput */.cQ)());
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            renderSceen(),
            /*#__PURE__*/ jsx_runtime_.jsx(components_Footer, {})
        ]
    });
};
/* harmony default export */ const page = (BuyCarInsurance);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [843,19,792], () => (__webpack_exec__(1371)));
module.exports = __webpack_exports__;

})();