exports.id = 19;
exports.ids = [19];
exports.modules = {

/***/ 9325:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ emotion_is_prop_valid_esm)
});

;// CONCATENATED MODULE: ./node_modules/@emotion/memoize/dist/emotion-memoize.esm.js
function memoize(fn) {
  var cache = Object.create(null);
  return function (arg) {
    if (cache[arg] === undefined) cache[arg] = fn(arg);
    return cache[arg];
  };
}

/* harmony default export */ const emotion_memoize_esm = (memoize);

;// CONCATENATED MODULE: ./node_modules/@emotion/is-prop-valid/dist/emotion-is-prop-valid.esm.js


var reactPropsRegex = /^((children|dangerouslySetInnerHTML|key|ref|autoFocus|defaultValue|defaultChecked|innerHTML|suppressContentEditableWarning|suppressHydrationWarning|valueLink|abbr|accept|acceptCharset|accessKey|action|allow|allowUserMedia|allowPaymentRequest|allowFullScreen|allowTransparency|alt|async|autoComplete|autoPlay|capture|cellPadding|cellSpacing|challenge|charSet|checked|cite|classID|className|cols|colSpan|content|contentEditable|contextMenu|controls|controlsList|coords|crossOrigin|data|dateTime|decoding|default|defer|dir|disabled|disablePictureInPicture|download|draggable|encType|enterKeyHint|form|formAction|formEncType|formMethod|formNoValidate|formTarget|frameBorder|headers|height|hidden|high|href|hrefLang|htmlFor|httpEquiv|id|inputMode|integrity|is|keyParams|keyType|kind|label|lang|list|loading|loop|low|marginHeight|marginWidth|max|maxLength|media|mediaGroup|method|min|minLength|multiple|muted|name|nonce|noValidate|open|optimum|pattern|placeholder|playsInline|poster|preload|profile|radioGroup|readOnly|referrerPolicy|rel|required|reversed|role|rows|rowSpan|sandbox|scope|scoped|scrolling|seamless|selected|shape|size|sizes|slot|span|spellCheck|src|srcDoc|srcLang|srcSet|start|step|style|summary|tabIndex|target|title|translate|type|useMap|value|width|wmode|wrap|about|datatype|inlist|prefix|property|resource|typeof|vocab|autoCapitalize|autoCorrect|autoSave|color|incremental|fallback|inert|itemProp|itemScope|itemType|itemID|itemRef|on|option|results|security|unselectable|accentHeight|accumulate|additive|alignmentBaseline|allowReorder|alphabetic|amplitude|arabicForm|ascent|attributeName|attributeType|autoReverse|azimuth|baseFrequency|baselineShift|baseProfile|bbox|begin|bias|by|calcMode|capHeight|clip|clipPathUnits|clipPath|clipRule|colorInterpolation|colorInterpolationFilters|colorProfile|colorRendering|contentScriptType|contentStyleType|cursor|cx|cy|d|decelerate|descent|diffuseConstant|direction|display|divisor|dominantBaseline|dur|dx|dy|edgeMode|elevation|enableBackground|end|exponent|externalResourcesRequired|fill|fillOpacity|fillRule|filter|filterRes|filterUnits|floodColor|floodOpacity|focusable|fontFamily|fontSize|fontSizeAdjust|fontStretch|fontStyle|fontVariant|fontWeight|format|from|fr|fx|fy|g1|g2|glyphName|glyphOrientationHorizontal|glyphOrientationVertical|glyphRef|gradientTransform|gradientUnits|hanging|horizAdvX|horizOriginX|ideographic|imageRendering|in|in2|intercept|k|k1|k2|k3|k4|kernelMatrix|kernelUnitLength|kerning|keyPoints|keySplines|keyTimes|lengthAdjust|letterSpacing|lightingColor|limitingConeAngle|local|markerEnd|markerMid|markerStart|markerHeight|markerUnits|markerWidth|mask|maskContentUnits|maskUnits|mathematical|mode|numOctaves|offset|opacity|operator|order|orient|orientation|origin|overflow|overlinePosition|overlineThickness|panose1|paintOrder|pathLength|patternContentUnits|patternTransform|patternUnits|pointerEvents|points|pointsAtX|pointsAtY|pointsAtZ|preserveAlpha|preserveAspectRatio|primitiveUnits|r|radius|refX|refY|renderingIntent|repeatCount|repeatDur|requiredExtensions|requiredFeatures|restart|result|rotate|rx|ry|scale|seed|shapeRendering|slope|spacing|specularConstant|specularExponent|speed|spreadMethod|startOffset|stdDeviation|stemh|stemv|stitchTiles|stopColor|stopOpacity|strikethroughPosition|strikethroughThickness|string|stroke|strokeDasharray|strokeDashoffset|strokeLinecap|strokeLinejoin|strokeMiterlimit|strokeOpacity|strokeWidth|surfaceScale|systemLanguage|tableValues|targetX|targetY|textAnchor|textDecoration|textRendering|textLength|to|transform|u1|u2|underlinePosition|underlineThickness|unicode|unicodeBidi|unicodeRange|unitsPerEm|vAlphabetic|vHanging|vIdeographic|vMathematical|values|vectorEffect|version|vertAdvY|vertOriginX|vertOriginY|viewBox|viewTarget|visibility|widths|wordSpacing|writingMode|x|xHeight|x1|x2|xChannelSelector|xlinkActuate|xlinkArcrole|xlinkHref|xlinkRole|xlinkShow|xlinkTitle|xlinkType|xmlBase|xmlns|xmlnsXlink|xmlLang|xmlSpace|y|y1|y2|yChannelSelector|z|zoomAndPan|for|class|autofocus)|(([Dd][Aa][Tt][Aa]|[Aa][Rr][Ii][Aa]|x)-.*))$/; // https://esbench.com/bench/5bfee68a4cd7e6009ef61d23

var isPropValid = /* #__PURE__ */emotion_memoize_esm(function (prop) {
  return reactPropsRegex.test(prop) || prop.charCodeAt(0) === 111
  /* o */
  && prop.charCodeAt(1) === 110
  /* n */
  && prop.charCodeAt(2) < 91;
}
/* Z+1 */
);

/* harmony default export */ const emotion_is_prop_valid_esm = (isPropValid);


/***/ }),

/***/ 8921:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


if (true) {
  module.exports = __webpack_require__(8281);
} else {}


/***/ }),

/***/ 8281:
/***/ ((__unused_webpack_module, exports) => {

"use strict";


function stylis_min(W) {
  function X(d, c, e) {
    var h = c.trim().split(ia);
    c = h;
    var a = h.length, m = d.length;
    switch (m) {
     case 0:
     case 1:
      var b = 0;
      for (d = 0 === m ? "" : d[0] + " "; b < a; ++b) c[b] = Z(d, c[b], e).trim();
      break;

     default:
      var v = b = 0;
      for (c = []; b < a; ++b) for (var n = 0; n < m; ++n) c[v++] = Z(d[n] + " ", h[b], e).trim();
    }
    return c;
  }
  function Z(d, c, e) {
    var h = c.charCodeAt(0);
    switch (33 > h && (h = (c = c.trim()).charCodeAt(0)), h) {
     case 38:
      return c.replace(F, "$1" + d.trim());

     case 58:
      return d.trim() + c.replace(F, "$1" + d.trim());

     default:
      if (0 < 1 * e && 0 < c.indexOf("\f")) return c.replace(F, (58 === d.charCodeAt(0) ? "" : "$1") + d.trim());
    }
    return d + c;
  }
  function P(d, c, e, h) {
    var a = d + ";", m = 2 * c + 3 * e + 4 * h;
    if (944 === m) {
      d = a.indexOf(":", 9) + 1;
      var b = a.substring(d, a.length - 1).trim();
      return b = a.substring(0, d).trim() + b + ";", 1 === w || 2 === w && L(b, 1) ? "-webkit-" + b + b : b;
    }
    if (0 === w || 2 === w && !L(a, 1)) return a;
    switch (m) {
     case 1015:
      return 97 === a.charCodeAt(10) ? "-webkit-" + a + a : a;

     case 951:
      return 116 === a.charCodeAt(3) ? "-webkit-" + a + a : a;

     case 963:
      return 110 === a.charCodeAt(5) ? "-webkit-" + a + a : a;

     case 1009:
      if (100 !== a.charCodeAt(4)) break;

     case 969:
     case 942:
      return "-webkit-" + a + a;

     case 978:
      return "-webkit-" + a + "-moz-" + a + a;

     case 1019:
     case 983:
      return "-webkit-" + a + "-moz-" + a + "-ms-" + a + a;

     case 883:
      if (45 === a.charCodeAt(8)) return "-webkit-" + a + a;
      if (0 < a.indexOf("image-set(", 11)) return a.replace(ja, "$1-webkit-$2") + a;
      break;

     case 932:
      if (45 === a.charCodeAt(4)) switch (a.charCodeAt(5)) {
       case 103:
        return "-webkit-box-" + a.replace("-grow", "") + "-webkit-" + a + "-ms-" + a.replace("grow", "positive") + a;

       case 115:
        return "-webkit-" + a + "-ms-" + a.replace("shrink", "negative") + a;

       case 98:
        return "-webkit-" + a + "-ms-" + a.replace("basis", "preferred-size") + a;
      }
      return "-webkit-" + a + "-ms-" + a + a;

     case 964:
      return "-webkit-" + a + "-ms-flex-" + a + a;

     case 1023:
      if (99 !== a.charCodeAt(8)) break;
      return "-webkit-box-pack" + (b = a.substring(a.indexOf(":", 15)).replace("flex-", "").replace("space-between", "justify")) + "-webkit-" + a + "-ms-flex-pack" + b + a;

     case 1005:
      return ka.test(a) ? a.replace(aa, ":-webkit-") + a.replace(aa, ":-moz-") + a : a;

     case 1e3:
      switch (c = (b = a.substring(13).trim()).indexOf("-") + 1, b.charCodeAt(0) + b.charCodeAt(c)) {
       case 226:
        b = a.replace(G, "tb");
        break;

       case 232:
        b = a.replace(G, "tb-rl");
        break;

       case 220:
        b = a.replace(G, "lr");
        break;

       default:
        return a;
      }
      return "-webkit-" + a + "-ms-" + b + a;

     case 1017:
      if (-1 === a.indexOf("sticky", 9)) break;

     case 975:
      switch (c = (a = d).length - 10, m = (b = (33 === a.charCodeAt(c) ? a.substring(0, c) : a).substring(d.indexOf(":", 7) + 1).trim()).charCodeAt(0) + (0 | b.charCodeAt(7))) {
       case 203:
        if (111 > b.charCodeAt(8)) break;

       case 115:
        a = a.replace(b, "-webkit-" + b) + ";" + a;
        break;

       case 207:
       case 102:
        a = a.replace(b, "-webkit-" + (102 < m ? "inline-" : "") + "box") + ";" + a.replace(b, "-webkit-" + b) + ";" + a.replace(b, "-ms-" + b + "box") + ";" + a;
      }
      return a + ";";

     case 938:
      if (45 === a.charCodeAt(5)) switch (a.charCodeAt(6)) {
       case 105:
        return b = a.replace("-items", ""), "-webkit-" + a + "-webkit-box-" + b + "-ms-flex-" + b + a;

       case 115:
        return "-webkit-" + a + "-ms-flex-item-" + a.replace(ba, "") + a;

       default:
        return "-webkit-" + a + "-ms-flex-line-pack" + a.replace("align-content", "").replace(ba, "") + a;
      }
      break;

     case 973:
     case 989:
      if (45 !== a.charCodeAt(3) || 122 === a.charCodeAt(4)) break;

     case 931:
     case 953:
      if (!0 === la.test(d)) return 115 === (b = d.substring(d.indexOf(":") + 1)).charCodeAt(0) ? P(d.replace("stretch", "fill-available"), c, e, h).replace(":fill-available", ":stretch") : a.replace(b, "-webkit-" + b) + a.replace(b, "-moz-" + b.replace("fill-", "")) + a;
      break;

     case 962:
      if (a = "-webkit-" + a + (102 === a.charCodeAt(5) ? "-ms-" + a : "") + a, 211 === e + h && 105 === a.charCodeAt(13) && 0 < a.indexOf("transform", 10)) return a.substring(0, a.indexOf(";", 27) + 1).replace(ma, "$1-webkit-$2") + a;
    }
    return a;
  }
  function L(d, c) {
    var e = d.indexOf(1 === c ? ":" : "{"), h = d.substring(0, 3 !== c ? e : 10);
    return e = d.substring(e + 1, d.length - 1), R(2 !== c ? h : h.replace(na, "$1"), e, c);
  }
  function ea(d, c) {
    var e = P(c, c.charCodeAt(0), c.charCodeAt(1), c.charCodeAt(2));
    return e !== c + ";" ? e.replace(oa, " or ($1)").substring(4) : "(" + c + ")";
  }
  function H(d, c, e, h, a, m, b, v, n, q) {
    for (var w, g = 0, x = c; g < A; ++g) switch (w = S[g].call(B, d, x, e, h, a, m, b, v, n, q)) {
     case void 0:
     case !1:
     case !0:
     case null:
      break;

     default:
      x = w;
    }
    if (x !== c) return x;
  }
  function U(d) {
    return void 0 !== (d = d.prefix) && (R = null, d ? "function" != typeof d ? w = 1 : (w = 2, 
    R = d) : w = 0), U;
  }
  function B(d, c) {
    var e = d;
    if (33 > e.charCodeAt(0) && (e = e.trim()), e = [ e ], 0 < A) {
      var h = H(-1, c, e, e, D, z, 0, 0, 0, 0);
      void 0 !== h && "string" == typeof h && (c = h);
    }
    var a = function M(d, c, e, h, a) {
      for (var q, g, k, y, C, m = 0, b = 0, v = 0, n = 0, x = 0, K = 0, u = k = q = 0, l = 0, r = 0, I = 0, t = 0, B = e.length, J = B - 1, f = "", p = "", F = "", G = ""; l < B; ) {
        if (g = e.charCodeAt(l), l === J && 0 !== b + n + v + m && (0 !== b && (g = 47 === b ? 10 : 47), 
        n = v = m = 0, B++, J++), 0 === b + n + v + m) {
          if (l === J && (0 < r && (f = f.replace(N, "")), 0 < f.trim().length)) {
            switch (g) {
             case 32:
             case 9:
             case 59:
             case 13:
             case 10:
              break;

             default:
              f += e.charAt(l);
            }
            g = 59;
          }
          switch (g) {
           case 123:
            for (q = (f = f.trim()).charCodeAt(0), k = 1, t = ++l; l < B; ) {
              switch (g = e.charCodeAt(l)) {
               case 123:
                k++;
                break;

               case 125:
                k--;
                break;

               case 47:
                switch (g = e.charCodeAt(l + 1)) {
                 case 42:
                 case 47:
                  a: {
                    for (u = l + 1; u < J; ++u) switch (e.charCodeAt(u)) {
                     case 47:
                      if (42 === g && 42 === e.charCodeAt(u - 1) && l + 2 !== u) {
                        l = u + 1;
                        break a;
                      }
                      break;

                     case 10:
                      if (47 === g) {
                        l = u + 1;
                        break a;
                      }
                    }
                    l = u;
                  }
                }
                break;

               case 91:
                g++;

               case 40:
                g++;

               case 34:
               case 39:
                for (;l++ < J && e.charCodeAt(l) !== g; ) ;
              }
              if (0 === k) break;
              l++;
            }
            switch (k = e.substring(t, l), 0 === q && (q = (f = f.replace(ca, "").trim()).charCodeAt(0)), 
            q) {
             case 64:
              switch (0 < r && (f = f.replace(N, "")), g = f.charCodeAt(1)) {
               case 100:
               case 109:
               case 115:
               case 45:
                r = c;
                break;

               default:
                r = O;
              }
              if (t = (k = M(c, r, k, g, a + 1)).length, 0 < A && (C = H(3, k, r = X(O, f, I), c, D, z, t, g, a, h), 
              f = r.join(""), void 0 !== C && 0 === (t = (k = C.trim()).length) && (g = 0, k = "")), 
              0 < t) switch (g) {
               case 115:
                f = f.replace(da, ea);

               case 100:
               case 109:
               case 45:
                k = f + "{" + k + "}";
                break;

               case 107:
                k = (f = f.replace(fa, "$1 $2")) + "{" + k + "}", k = 1 === w || 2 === w && L("@" + k, 3) ? "@-webkit-" + k + "@" + k : "@" + k;
                break;

               default:
                k = f + k, 112 === h && (p += k, k = "");
              } else k = "";
              break;

             default:
              k = M(c, X(c, f, I), k, h, a + 1);
            }
            F += k, k = I = r = u = q = 0, f = "", g = e.charCodeAt(++l);
            break;

           case 125:
           case 59:
            if (1 < (t = (f = (0 < r ? f.replace(N, "") : f).trim()).length)) switch (0 === u && (q = f.charCodeAt(0), 
            45 === q || 96 < q && 123 > q) && (t = (f = f.replace(" ", ":")).length), 0 < A && void 0 !== (C = H(1, f, c, d, D, z, p.length, h, a, h)) && 0 === (t = (f = C.trim()).length) && (f = "\0\0"), 
            q = f.charCodeAt(0), g = f.charCodeAt(1), q) {
             case 0:
              break;

             case 64:
              if (105 === g || 99 === g) {
                G += f + e.charAt(l);
                break;
              }

             default:
              58 !== f.charCodeAt(t - 1) && (p += P(f, q, g, f.charCodeAt(2)));
            }
            I = r = u = q = 0, f = "", g = e.charCodeAt(++l);
          }
        }
        switch (g) {
         case 13:
         case 10:
          47 === b ? b = 0 : 0 === 1 + q && 107 !== h && 0 < f.length && (r = 1, f += "\0"), 
          0 < A * Y && H(0, f, c, d, D, z, p.length, h, a, h), z = 1, D++;
          break;

         case 59:
         case 125:
          if (0 === b + n + v + m) {
            z++;
            break;
          }

         default:
          switch (z++, y = e.charAt(l), g) {
           case 9:
           case 32:
            if (0 === n + m + b) switch (x) {
             case 44:
             case 58:
             case 9:
             case 32:
              y = "";
              break;

             default:
              32 !== g && (y = " ");
            }
            break;

           case 0:
            y = "\\0";
            break;

           case 12:
            y = "\\f";
            break;

           case 11:
            y = "\\v";
            break;

           case 38:
            0 === n + b + m && (r = I = 1, y = "\f" + y);
            break;

           case 108:
            if (0 === n + b + m + E && 0 < u) switch (l - u) {
             case 2:
              112 === x && 58 === e.charCodeAt(l - 3) && (E = x);

             case 8:
              111 === K && (E = K);
            }
            break;

           case 58:
            0 === n + b + m && (u = l);
            break;

           case 44:
            0 === b + v + n + m && (r = 1, y += "\r");
            break;

           case 34:
           case 39:
            0 === b && (n = n === g ? 0 : 0 === n ? g : n);
            break;

           case 91:
            0 === n + b + v && m++;
            break;

           case 93:
            0 === n + b + v && m--;
            break;

           case 41:
            0 === n + b + m && v--;
            break;

           case 40:
            if (0 === n + b + m) {
              if (0 === q) switch (2 * x + 3 * K) {
               case 533:
                break;

               default:
                q = 1;
              }
              v++;
            }
            break;

           case 64:
            0 === b + v + n + m + u + k && (k = 1);
            break;

           case 42:
           case 47:
            if (!(0 < n + m + v)) switch (b) {
             case 0:
              switch (2 * g + 3 * e.charCodeAt(l + 1)) {
               case 235:
                b = 47;
                break;

               case 220:
                t = l, b = 42;
              }
              break;

             case 42:
              47 === g && 42 === x && t + 2 !== l && (33 === e.charCodeAt(t + 2) && (p += e.substring(t, l + 1)), 
              y = "", b = 0);
            }
          }
          0 === b && (f += y);
        }
        K = x, x = g, l++;
      }
      if (0 < (t = p.length)) {
        if (r = c, 0 < A && void 0 !== (C = H(2, p, r, d, D, z, t, h, a, h)) && 0 === (p = C).length) return G + p + F;
        if (p = r.join(",") + "{" + p + "}", 0 != w * E) {
          switch (2 !== w || L(p, 2) || (E = 0), E) {
           case 111:
            p = p.replace(ha, ":-moz-$1") + p;
            break;

           case 112:
            p = p.replace(Q, "::-webkit-input-$1") + p.replace(Q, "::-moz-$1") + p.replace(Q, ":-ms-input-$1") + p;
          }
          E = 0;
        }
      }
      return G + p + F;
    }(O, e, c, 0, 0);
    return 0 < A && (void 0 !== (h = H(-2, a, e, e, D, z, a.length, 0, 0, 0)) && (a = h)), 
    "", E = 0, z = D = 1, a;
  }
  var ca = /^\0+/g, N = /[\0\r\f]/g, aa = /: */g, ka = /zoo|gra/, ma = /([,: ])(transform)/g, ia = /,\r+?/g, F = /([\t\r\n ])*\f?&/g, fa = /@(k\w+)\s*(\S*)\s*/, Q = /::(place)/g, ha = /:(read-only)/g, G = /[svh]\w+-[tblr]{2}/, da = /\(\s*(.*)\s*\)/g, oa = /([\s\S]*?);/g, ba = /-self|flex-/g, na = /[^]*?(:[rp][el]a[\w-]+)[^]*/, la = /stretch|:\s*\w+\-(?:conte|avail)/, ja = /([^-])(image-set\()/, z = 1, D = 1, E = 0, w = 1, O = [], S = [], A = 0, R = null, Y = 0;
  return B.use = function T(d) {
    switch (d) {
     case void 0:
     case null:
      A = S.length = 0;
      break;

     default:
      if ("function" == typeof d) S[A++] = d; else if ("object" == typeof d) for (var c = 0, e = d.length; c < e; ++c) T(d[c]); else Y = 0 | !!d;
    }
    return T;
  }, B.set = U, void 0 !== W && U(W), B;
}

Object.defineProperty(exports, "__esModule", ({
  value: !0
})), exports["default"] = stylis_min;


/***/ }),

/***/ 2477:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


if (true) {
  module.exports = __webpack_require__(7028);
} else {}


/***/ }),

/***/ 7028:
/***/ ((__unused_webpack_module, exports) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: !0
}));

var unitlessKeys = {
  animationIterationCount: 1,
  borderImageOutset: 1,
  borderImageSlice: 1,
  borderImageWidth: 1,
  boxFlex: 1,
  boxFlexGroup: 1,
  boxOrdinalGroup: 1,
  columnCount: 1,
  columns: 1,
  flex: 1,
  flexGrow: 1,
  flexPositive: 1,
  flexShrink: 1,
  flexNegative: 1,
  flexOrder: 1,
  gridRow: 1,
  gridRowEnd: 1,
  gridRowSpan: 1,
  gridRowStart: 1,
  gridColumn: 1,
  gridColumnEnd: 1,
  gridColumnSpan: 1,
  gridColumnStart: 1,
  msGridRow: 1,
  msGridRowSpan: 1,
  msGridColumn: 1,
  msGridColumnSpan: 1,
  fontWeight: 1,
  lineHeight: 1,
  opacity: 1,
  order: 1,
  orphans: 1,
  tabSize: 1,
  widows: 1,
  zIndex: 1,
  zoom: 1,
  WebkitLineClamp: 1,
  fillOpacity: 1,
  floodOpacity: 1,
  stopOpacity: 1,
  strokeDasharray: 1,
  strokeDashoffset: 1,
  strokeMiterlimit: 1,
  strokeOpacity: 1,
  strokeWidth: 1
};

exports["default"] = unitlessKeys;


/***/ }),

/***/ 1824:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

(function (global, factory) {
     true ? factory(exports, __webpack_require__(8038)) :
    0;
}(this, (function (exports, React) { 'use strict';

    function _interopDefaultLegacy (e) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }

    var React__default = /*#__PURE__*/_interopDefaultLegacy(React);

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.

    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __spreadArray(to, from, pack) {
        if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
            if (ar || !(i in from)) {
                if (!ar) ar = Array.prototype.slice.call(from, 0, i);
                ar[i] = from[i];
            }
        }
        return to.concat(ar || from);
    }

    /**
     * Escape regex char
     *
     * See: https://stackoverflow.com/questions/17885855/use-dynamic-variable-string-as-regex-pattern-in-javascript
     */
    var escapeRegExp = function (stringToGoIntoTheRegex) {
        return stringToGoIntoTheRegex.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
    };

    var abbrMap = { k: 1000, m: 1000000, b: 1000000000 };
    /**
     * Parse a value with abbreviation e.g 1k = 1000
     */
    var parseAbbrValue = function (value, decimalSeparator) {
        if (decimalSeparator === void 0) { decimalSeparator = '.'; }
        var reg = new RegExp("(\\d+(" + escapeRegExp(decimalSeparator) + "\\d*)?)([kmb])$", 'i');
        var match = value.match(reg);
        if (match) {
            var digits = match[1], abbr = match[3];
            var multiplier = abbrMap[abbr.toLowerCase()];
            return Number(digits.replace(decimalSeparator, '.')) * multiplier;
        }
        return undefined;
    };

    /**
     * Remove group separator from value eg. 1,000 > 1000
     */
    var removeSeparators = function (value, separator) {
        if (separator === void 0) { separator = ','; }
        var reg = new RegExp(escapeRegExp(separator), 'g');
        return value.replace(reg, '');
    };

    /**
     * Remove invalid characters
     */
    var removeInvalidChars = function (value, validChars) {
        var chars = escapeRegExp(validChars.join(''));
        var reg = new RegExp("[^\\d" + chars + "]", 'gi');
        return value.replace(reg, '');
    };

    /**
     * Remove prefix, separators and extra decimals from value
     */
    var cleanValue = function (_a) {
        var value = _a.value, _b = _a.groupSeparator, groupSeparator = _b === void 0 ? ',' : _b, _c = _a.decimalSeparator, decimalSeparator = _c === void 0 ? '.' : _c, _d = _a.allowDecimals, allowDecimals = _d === void 0 ? true : _d, _e = _a.decimalsLimit, decimalsLimit = _e === void 0 ? 2 : _e, _f = _a.allowNegativeValue, allowNegativeValue = _f === void 0 ? true : _f, _g = _a.disableAbbreviations, disableAbbreviations = _g === void 0 ? false : _g, _h = _a.prefix, prefix = _h === void 0 ? '' : _h, _j = _a.transformRawValue, transformRawValue = _j === void 0 ? function (rawValue) { return rawValue; } : _j;
        var transformedValue = transformRawValue(value);
        if (transformedValue === '-') {
            return transformedValue;
        }
        var abbreviations = disableAbbreviations ? [] : ['k', 'm', 'b'];
        var reg = new RegExp("((^|\\D)-\\d)|(-" + escapeRegExp(prefix) + ")");
        var isNegative = reg.test(transformedValue);
        // Is there a digit before the prefix? eg. 1$
        var _k = RegExp("(\\d+)-?" + escapeRegExp(prefix)).exec(value) || [], prefixWithValue = _k[0], preValue = _k[1];
        var withoutPrefix = prefix
            ? prefixWithValue
                ? transformedValue.replace(prefixWithValue, '').concat(preValue)
                : transformedValue.replace(prefix, '')
            : transformedValue;
        var withoutSeparators = removeSeparators(withoutPrefix, groupSeparator);
        var withoutInvalidChars = removeInvalidChars(withoutSeparators, __spreadArray([
            groupSeparator,
            decimalSeparator
        ], abbreviations));
        var valueOnly = withoutInvalidChars;
        if (!disableAbbreviations) {
            // disallow letter without number
            if (abbreviations.some(function (letter) { return letter === withoutInvalidChars.toLowerCase(); })) {
                return '';
            }
            var parsed = parseAbbrValue(withoutInvalidChars, decimalSeparator);
            if (parsed) {
                valueOnly = String(parsed);
            }
        }
        var includeNegative = isNegative && allowNegativeValue ? '-' : '';
        if (decimalSeparator && valueOnly.includes(decimalSeparator)) {
            var _l = withoutInvalidChars.split(decimalSeparator), int = _l[0], decimals = _l[1];
            var trimmedDecimals = decimalsLimit && decimals ? decimals.slice(0, decimalsLimit) : decimals;
            var includeDecimals = allowDecimals ? "" + decimalSeparator + trimmedDecimals : '';
            return "" + includeNegative + int + includeDecimals;
        }
        return "" + includeNegative + valueOnly;
    };

    var fixedDecimalValue = function (value, decimalSeparator, fixedDecimalLength) {
        if (fixedDecimalLength && value.length > 1) {
            if (value.includes(decimalSeparator)) {
                var _a = value.split(decimalSeparator), int = _a[0], decimals = _a[1];
                if (decimals.length > fixedDecimalLength) {
                    return "" + int + decimalSeparator + decimals.slice(0, fixedDecimalLength);
                }
            }
            var reg = value.length > fixedDecimalLength
                ? new RegExp("(\\d+)(\\d{" + fixedDecimalLength + "})")
                : new RegExp("(\\d)(\\d+)");
            var match = value.match(reg);
            if (match) {
                var int = match[1], decimals = match[2];
                return "" + int + decimalSeparator + decimals;
            }
        }
        return value;
    };

    var getSuffix = function (value, _a) {
        var _b = _a.groupSeparator, groupSeparator = _b === void 0 ? ',' : _b, _c = _a.decimalSeparator, decimalSeparator = _c === void 0 ? '.' : _c;
        var suffixReg = new RegExp("\\d([^" + escapeRegExp(groupSeparator) + escapeRegExp(decimalSeparator) + "0-9]+)");
        var suffixMatch = value.match(suffixReg);
        return suffixMatch ? suffixMatch[1] : undefined;
    };

    /**
     * Format value with decimal separator, group separator and prefix
     */
    var formatValue = function (options) {
        var _value = options.value, decimalSeparator = options.decimalSeparator, intlConfig = options.intlConfig, decimalScale = options.decimalScale, _a = options.prefix, prefix = _a === void 0 ? '' : _a, _b = options.suffix, suffix = _b === void 0 ? '' : _b;
        if (_value === '' || _value === undefined) {
            return '';
        }
        if (_value === '-') {
            return '-';
        }
        var isNegative = new RegExp("^\\d?-" + (prefix ? escapeRegExp(prefix) + "?" : '') + "\\d").test(_value);
        var value = decimalSeparator !== '.'
            ? replaceDecimalSeparator(_value, decimalSeparator, isNegative)
            : _value;
        var defaultNumberFormatOptions = {
            minimumFractionDigits: decimalScale || 0,
            maximumFractionDigits: 20,
        };
        var numberFormatter = intlConfig
            ? new Intl.NumberFormat(intlConfig.locale, intlConfig.currency
                ? __assign(__assign({}, defaultNumberFormatOptions), { style: 'currency', currency: intlConfig.currency }) : defaultNumberFormatOptions)
            : new Intl.NumberFormat(undefined, defaultNumberFormatOptions);
        var parts = numberFormatter.formatToParts(Number(value));
        var formatted = replaceParts(parts, options);
        // Does intl formatting add a suffix?
        var intlSuffix = getSuffix(formatted, __assign({}, options));
        // Include decimal separator if user input ends with decimal separator
        var includeDecimalSeparator = _value.slice(-1) === decimalSeparator ? decimalSeparator : '';
        var _c = value.match(RegExp('\\d+\\.(\\d+)')) || [], decimals = _c[1];
        // Keep original decimal padding if no decimalScale
        if (decimalScale === undefined && decimals && decimalSeparator) {
            if (formatted.includes(decimalSeparator)) {
                formatted = formatted.replace(RegExp("(\\d+)(" + escapeRegExp(decimalSeparator) + ")(\\d+)", 'g'), "$1$2" + decimals);
            }
            else {
                if (intlSuffix && !suffix) {
                    formatted = formatted.replace(intlSuffix, "" + decimalSeparator + decimals + intlSuffix);
                }
                else {
                    formatted = "" + formatted + decimalSeparator + decimals;
                }
            }
        }
        if (suffix && includeDecimalSeparator) {
            return "" + formatted + includeDecimalSeparator + suffix;
        }
        if (intlSuffix && includeDecimalSeparator) {
            return formatted.replace(intlSuffix, "" + includeDecimalSeparator + intlSuffix);
        }
        if (intlSuffix && suffix) {
            return formatted.replace(intlSuffix, "" + includeDecimalSeparator + suffix);
        }
        return [formatted, includeDecimalSeparator, suffix].join('');
    };
    /**
     * Before converting to Number, decimal separator has to be .
     */
    var replaceDecimalSeparator = function (value, decimalSeparator, isNegative) {
        var newValue = value;
        if (decimalSeparator && decimalSeparator !== '.') {
            newValue = newValue.replace(RegExp(escapeRegExp(decimalSeparator), 'g'), '.');
            if (isNegative && decimalSeparator === '-') {
                newValue = "-" + newValue.slice(1);
            }
        }
        return newValue;
    };
    var replaceParts = function (parts, _a) {
        var prefix = _a.prefix, groupSeparator = _a.groupSeparator, decimalSeparator = _a.decimalSeparator, decimalScale = _a.decimalScale, _b = _a.disableGroupSeparators, disableGroupSeparators = _b === void 0 ? false : _b;
        return parts
            .reduce(function (prev, _a, i) {
            var type = _a.type, value = _a.value;
            if (i === 0 && prefix) {
                if (type === 'minusSign') {
                    return [value, prefix];
                }
                if (type === 'currency') {
                    return __spreadArray(__spreadArray([], prev), [prefix]);
                }
                return [prefix, value];
            }
            if (type === 'currency') {
                return prefix ? prev : __spreadArray(__spreadArray([], prev), [value]);
            }
            if (type === 'group') {
                return !disableGroupSeparators
                    ? __spreadArray(__spreadArray([], prev), [groupSeparator !== undefined ? groupSeparator : value]) : prev;
            }
            if (type === 'decimal') {
                if (decimalScale !== undefined && decimalScale === 0) {
                    return prev;
                }
                return __spreadArray(__spreadArray([], prev), [decimalSeparator !== undefined ? decimalSeparator : value]);
            }
            if (type === 'fraction') {
                return __spreadArray(__spreadArray([], prev), [decimalScale !== undefined ? value.slice(0, decimalScale) : value]);
            }
            return __spreadArray(__spreadArray([], prev), [value]);
        }, [''])
            .join('');
    };

    var defaultConfig = {
        currencySymbol: '',
        groupSeparator: '',
        decimalSeparator: '',
        prefix: '',
        suffix: '',
    };
    /**
     * Get locale config from input or default
     */
    var getLocaleConfig = function (intlConfig) {
        var _a = intlConfig || {}, locale = _a.locale, currency = _a.currency;
        var numberFormatter = locale
            ? new Intl.NumberFormat(locale, currency ? { currency: currency, style: 'currency' } : undefined)
            : new Intl.NumberFormat();
        return numberFormatter.formatToParts(1000.1).reduce(function (prev, curr, i) {
            if (curr.type === 'currency') {
                if (i === 0) {
                    return __assign(__assign({}, prev), { currencySymbol: curr.value, prefix: curr.value });
                }
                else {
                    return __assign(__assign({}, prev), { currencySymbol: curr.value, suffix: curr.value });
                }
            }
            if (curr.type === 'group') {
                return __assign(__assign({}, prev), { groupSeparator: curr.value });
            }
            if (curr.type === 'decimal') {
                return __assign(__assign({}, prev), { decimalSeparator: curr.value });
            }
            return prev;
        }, defaultConfig);
    };

    var isNumber = function (input) { return RegExp(/\d/, 'gi').test(input); };

    var padTrimValue = function (value, decimalSeparator, decimalScale) {
        if (decimalSeparator === void 0) { decimalSeparator = '.'; }
        if (decimalScale === undefined || value === '' || value === undefined) {
            return value;
        }
        if (!value.match(/\d/g)) {
            return '';
        }
        var _a = value.split(decimalSeparator), int = _a[0], decimals = _a[1];
        if (decimalScale === 0) {
            return int;
        }
        var newValue = decimals || '';
        if (newValue.length < decimalScale) {
            while (newValue.length < decimalScale) {
                newValue += '0';
            }
        }
        else {
            newValue = newValue.slice(0, decimalScale);
        }
        return "" + int + decimalSeparator + newValue;
    };

    /**
     * Based on the last key stroke and the cursor position, update the value
     * and reposition the cursor to the right place
     */
    var repositionCursor = function (_a) {
        var selectionStart = _a.selectionStart, value = _a.value, lastKeyStroke = _a.lastKeyStroke, stateValue = _a.stateValue, groupSeparator = _a.groupSeparator;
        var cursorPosition = selectionStart;
        var modifiedValue = value;
        if (stateValue && cursorPosition) {
            var splitValue = value.split('');
            // if cursor is to right of groupSeparator and backspace pressed, delete the character to the left of the separator and reposition the cursor
            if (lastKeyStroke === 'Backspace' && stateValue[cursorPosition] === groupSeparator) {
                splitValue.splice(cursorPosition - 1, 1);
                cursorPosition -= 1;
            }
            // if cursor is to left of groupSeparator and delete pressed, delete the character to the right of the separator and reposition the cursor
            if (lastKeyStroke === 'Delete' && stateValue[cursorPosition] === groupSeparator) {
                splitValue.splice(cursorPosition, 1);
                cursorPosition += 1;
            }
            modifiedValue = splitValue.join('');
            return { modifiedValue: modifiedValue, cursorPosition: cursorPosition };
        }
        return { modifiedValue: modifiedValue, cursorPosition: selectionStart };
    };

    var CurrencyInput = React.forwardRef(function (_a, ref) {
        var _b = _a.allowDecimals, allowDecimals = _b === void 0 ? true : _b, _c = _a.allowNegativeValue, allowNegativeValue = _c === void 0 ? true : _c, id = _a.id, name = _a.name, className = _a.className, customInput = _a.customInput, decimalsLimit = _a.decimalsLimit, defaultValue = _a.defaultValue, _d = _a.disabled, disabled = _d === void 0 ? false : _d, userMaxLength = _a.maxLength, userValue = _a.value, onValueChange = _a.onValueChange, fixedDecimalLength = _a.fixedDecimalLength, placeholder = _a.placeholder, decimalScale = _a.decimalScale, prefix = _a.prefix, suffix = _a.suffix, intlConfig = _a.intlConfig, step = _a.step, min = _a.min, max = _a.max, _e = _a.disableGroupSeparators, disableGroupSeparators = _e === void 0 ? false : _e, _f = _a.disableAbbreviations, disableAbbreviations = _f === void 0 ? false : _f, _decimalSeparator = _a.decimalSeparator, _groupSeparator = _a.groupSeparator, onChange = _a.onChange, onFocus = _a.onFocus, onBlur = _a.onBlur, onKeyDown = _a.onKeyDown, onKeyUp = _a.onKeyUp, transformRawValue = _a.transformRawValue, props = __rest(_a, ["allowDecimals", "allowNegativeValue", "id", "name", "className", "customInput", "decimalsLimit", "defaultValue", "disabled", "maxLength", "value", "onValueChange", "fixedDecimalLength", "placeholder", "decimalScale", "prefix", "suffix", "intlConfig", "step", "min", "max", "disableGroupSeparators", "disableAbbreviations", "decimalSeparator", "groupSeparator", "onChange", "onFocus", "onBlur", "onKeyDown", "onKeyUp", "transformRawValue"]);
        if (_decimalSeparator && isNumber(_decimalSeparator)) {
            throw new Error('decimalSeparator cannot be a number');
        }
        if (_groupSeparator && isNumber(_groupSeparator)) {
            throw new Error('groupSeparator cannot be a number');
        }
        var localeConfig = React.useMemo(function () { return getLocaleConfig(intlConfig); }, [intlConfig]);
        var decimalSeparator = _decimalSeparator || localeConfig.decimalSeparator || '';
        var groupSeparator = _groupSeparator || localeConfig.groupSeparator || '';
        if (decimalSeparator &&
            groupSeparator &&
            decimalSeparator === groupSeparator &&
            disableGroupSeparators === false) {
            throw new Error('decimalSeparator cannot be the same as groupSeparator');
        }
        var formatValueOptions = {
            decimalSeparator: decimalSeparator,
            groupSeparator: groupSeparator,
            disableGroupSeparators: disableGroupSeparators,
            intlConfig: intlConfig,
            prefix: prefix || localeConfig.prefix,
            suffix: suffix,
        };
        var cleanValueOptions = {
            decimalSeparator: decimalSeparator,
            groupSeparator: groupSeparator,
            allowDecimals: allowDecimals,
            decimalsLimit: decimalsLimit || fixedDecimalLength || 2,
            allowNegativeValue: allowNegativeValue,
            disableAbbreviations: disableAbbreviations,
            prefix: prefix || localeConfig.prefix,
            transformRawValue: transformRawValue,
        };
        var formattedStateValue = defaultValue !== undefined && defaultValue !== null
            ? formatValue(__assign(__assign({}, formatValueOptions), { decimalScale: decimalScale, value: String(defaultValue) }))
            : userValue !== undefined && userValue !== null
                ? formatValue(__assign(__assign({}, formatValueOptions), { decimalScale: decimalScale, value: String(userValue) }))
                : '';
        var _g = React.useState(formattedStateValue), stateValue = _g[0], setStateValue = _g[1];
        var _h = React.useState(false), dirty = _h[0], setDirty = _h[1];
        var _j = React.useState(0), cursor = _j[0], setCursor = _j[1];
        var _k = React.useState(0), changeCount = _k[0], setChangeCount = _k[1];
        var _l = React.useState(null), lastKeyStroke = _l[0], setLastKeyStroke = _l[1];
        var inputRef = React.useRef(null);
        React.useImperativeHandle(ref, function () { return inputRef.current; });
        /**
         * Process change in value
         */
        var processChange = function (value, selectionStart) {
            setDirty(true);
            var _a = repositionCursor({
                selectionStart: selectionStart,
                value: value,
                lastKeyStroke: lastKeyStroke,
                stateValue: stateValue,
                groupSeparator: groupSeparator,
            }), modifiedValue = _a.modifiedValue, cursorPosition = _a.cursorPosition;
            var stringValue = cleanValue(__assign({ value: modifiedValue }, cleanValueOptions));
            if (userMaxLength && stringValue.replace(/-/g, '').length > userMaxLength) {
                return;
            }
            if (stringValue === '' || stringValue === '-' || stringValue === decimalSeparator) {
                onValueChange && onValueChange(undefined, name, { float: null, formatted: '', value: '' });
                setStateValue(stringValue);
                return;
            }
            var stringValueWithoutSeparator = decimalSeparator
                ? stringValue.replace(decimalSeparator, '.')
                : stringValue;
            var numberValue = parseFloat(stringValueWithoutSeparator);
            var formattedValue = formatValue(__assign({ value: stringValue }, formatValueOptions));
            if (cursorPosition !== undefined && cursorPosition !== null) {
                // Prevent cursor jumping
                var newCursor = cursorPosition + (formattedValue.length - value.length);
                newCursor = newCursor <= 0 ? (prefix ? prefix.length : 0) : newCursor;
                setCursor(newCursor);
                setChangeCount(changeCount + 1);
            }
            setStateValue(formattedValue);
            if (onValueChange) {
                var values = {
                    float: numberValue,
                    formatted: formattedValue,
                    value: stringValue,
                };
                onValueChange(stringValue, name, values);
            }
        };
        /**
         * Handle change event
         */
        var handleOnChange = function (event) {
            var _a = event.target, value = _a.value, selectionStart = _a.selectionStart;
            processChange(value, selectionStart);
            onChange && onChange(event);
        };
        /**
         * Handle focus event
         */
        var handleOnFocus = function (event) {
            onFocus && onFocus(event);
            return stateValue ? stateValue.length : 0;
        };
        /**
         * Handle blur event
         *
         * Format value by padding/trimming decimals if required by
         */
        var handleOnBlur = function (event) {
            var value = event.target.value;
            var valueOnly = cleanValue(__assign({ value: value }, cleanValueOptions));
            if (valueOnly === '-' || !valueOnly) {
                setStateValue('');
                onBlur && onBlur(event);
                return;
            }
            var fixedDecimals = fixedDecimalValue(valueOnly, decimalSeparator, fixedDecimalLength);
            var newValue = padTrimValue(fixedDecimals, decimalSeparator, decimalScale !== undefined ? decimalScale : fixedDecimalLength);
            var numberValue = parseFloat(newValue.replace(decimalSeparator, '.'));
            var formattedValue = formatValue(__assign(__assign({}, formatValueOptions), { value: newValue }));
            if (onValueChange) {
                onValueChange(newValue, name, {
                    float: numberValue,
                    formatted: formattedValue,
                    value: newValue,
                });
            }
            setStateValue(formattedValue);
            onBlur && onBlur(event);
        };
        /**
         * Handle key down event
         *
         * Increase or decrease value by step
         */
        var handleOnKeyDown = function (event) {
            var key = event.key;
            setLastKeyStroke(key);
            if (step && (key === 'ArrowUp' || key === 'ArrowDown')) {
                event.preventDefault();
                setCursor(stateValue.length);
                var currentValue = parseFloat(userValue !== undefined && userValue !== null
                    ? String(userValue).replace(decimalSeparator, '.')
                    : cleanValue(__assign({ value: stateValue }, cleanValueOptions))) || 0;
                var newValue = key === 'ArrowUp' ? currentValue + step : currentValue - step;
                if (min !== undefined && newValue < min) {
                    return;
                }
                if (max !== undefined && newValue > max) {
                    return;
                }
                var fixedLength = String(step).includes('.')
                    ? Number(String(step).split('.')[1].length)
                    : undefined;
                processChange(String(fixedLength ? newValue.toFixed(fixedLength) : newValue).replace('.', decimalSeparator));
            }
            onKeyDown && onKeyDown(event);
        };
        /**
         * Handle key up event
         *
         * Move cursor if there is a suffix to prevent user typing past suffix
         */
        var handleOnKeyUp = function (event) {
            var key = event.key, selectionStart = event.currentTarget.selectionStart;
            if (key !== 'ArrowUp' && key !== 'ArrowDown' && stateValue !== '-') {
                var suffix_1 = getSuffix(stateValue, { groupSeparator: groupSeparator, decimalSeparator: decimalSeparator });
                if (suffix_1 && selectionStart && selectionStart > stateValue.length - suffix_1.length) {
                    /* istanbul ignore else */
                    if (inputRef.current) {
                        var newCursor = stateValue.length - suffix_1.length;
                        inputRef.current.setSelectionRange(newCursor, newCursor);
                    }
                }
            }
            onKeyUp && onKeyUp(event);
        };
        React.useEffect(function () {
            // prevent cursor jumping if editing value
            if (dirty &&
                stateValue !== '-' &&
                inputRef.current &&
                document.activeElement === inputRef.current) {
                inputRef.current.setSelectionRange(cursor, cursor);
            }
        }, [stateValue, cursor, inputRef, dirty, changeCount]);
        /**
         * If user has only entered "-" or decimal separator,
         * keep the char to allow them to enter next value
         */
        var getRenderValue = function () {
            if (userValue !== undefined &&
                userValue !== null &&
                stateValue !== '-' &&
                (!decimalSeparator || stateValue !== decimalSeparator)) {
                return formatValue(__assign(__assign({}, formatValueOptions), { decimalScale: dirty ? undefined : decimalScale, value: String(userValue) }));
            }
            return stateValue;
        };
        var inputProps = __assign({ type: 'text', inputMode: 'decimal', id: id,
            name: name,
            className: className, onChange: handleOnChange, onBlur: handleOnBlur, onFocus: handleOnFocus, onKeyDown: handleOnKeyDown, onKeyUp: handleOnKeyUp, placeholder: placeholder,
            disabled: disabled, value: getRenderValue(), ref: inputRef }, props);
        if (customInput) {
            var CustomInput = customInput;
            return React__default['default'].createElement(CustomInput, __assign({}, inputProps));
        }
        return React__default['default'].createElement("input", __assign({}, inputProps));
    });
    CurrencyInput.displayName = 'CurrencyInput';

    exports.default = CurrencyInput;
    exports.formatValue = formatValue;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=index.js.map


/***/ }),

/***/ 9438:
/***/ ((module) => {

//

module.exports = function shallowEqual(objA, objB, compare, compareContext) {
  var ret = compare ? compare.call(compareContext, objA, objB) : void 0;

  if (ret !== void 0) {
    return !!ret;
  }

  if (objA === objB) {
    return true;
  }

  if (typeof objA !== "object" || !objA || typeof objB !== "object" || !objB) {
    return false;
  }

  var keysA = Object.keys(objA);
  var keysB = Object.keys(objB);

  if (keysA.length !== keysB.length) {
    return false;
  }

  var bHasOwnProperty = Object.prototype.hasOwnProperty.bind(objB);

  // Test for A's keys different from B.
  for (var idx = 0; idx < keysA.length; idx++) {
    var key = keysA[idx];

    if (!bHasOwnProperty(key)) {
      return false;
    }

    var valueA = objA[key];
    var valueB = objB[key];

    ret = compare ? compare.call(compareContext, valueA, valueB, key) : void 0;

    if (ret === false || (ret === void 0 && valueA !== valueB)) {
      return false;
    }
  }

  return true;
};


/***/ }),

/***/ 3103:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
var __webpack_unused_export__;
function e(e){return e&&"object"==typeof e&&"default"in e?e.default:e}__webpack_unused_export__ = ({value:!0});var t=__webpack_require__(717),n=__webpack_require__(8038),r=e(n),o=e(__webpack_require__(9438)),s=e(__webpack_require__(8921)),i=e(__webpack_require__(2477)),a=e(__webpack_require__(9325)),c=e(__webpack_require__(1054));function u(){return(u=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e}).apply(this,arguments)}var l=function(e,t){for(var n=[e[0]],r=0,o=t.length;r<o;r+=1)n.push(t[r],e[r+1]);return n},d=function(e){return null!==e&&"object"==typeof e&&"[object Object]"===(e.toString?e.toString():Object.prototype.toString.call(e))&&!t.typeOf(e)},h=Object.freeze([]),p=Object.freeze({});function f(e){return"function"==typeof e}function m(e){return false||e.displayName||e.name||"Component"}function y(e){return e&&"string"==typeof e.styledComponentId}var v="undefined"!=typeof process&&(process.env.REACT_APP_SC_ATTR||process.env.SC_ATTR)||"data-styled",g="undefined"!=typeof window&&"HTMLElement"in window,S=Boolean("boolean"==typeof SC_DISABLE_SPEEDY?SC_DISABLE_SPEEDY:"undefined"!=typeof process&&void 0!==process.env.REACT_APP_SC_DISABLE_SPEEDY&&""!==process.env.REACT_APP_SC_DISABLE_SPEEDY?"false"!==process.env.REACT_APP_SC_DISABLE_SPEEDY&&process.env.REACT_APP_SC_DISABLE_SPEEDY:"undefined"!=typeof process&&void 0!==process.env.SC_DISABLE_SPEEDY&&""!==process.env.SC_DISABLE_SPEEDY?"false"!==process.env.SC_DISABLE_SPEEDY&&process.env.SC_DISABLE_SPEEDY:"production"!=="production"),w={},E= false?0:{};function b(){for(var e=arguments.length<=0?void 0:arguments[0],t=[],n=1,r=arguments.length;n<r;n+=1)t.push(n<0||arguments.length<=n?void 0:arguments[n]);return t.forEach((function(t){e=e.replace(/%[a-z]/,t)})),e}function _(e){for(var t=arguments.length,n=new Array(t>1?t-1:0),r=1;r<t;r++)n[r-1]=arguments[r];throw true?new Error("An error occurred. See https://git.io/JUIaE#"+e+" for more information."+(n.length>0?" Args: "+n.join(", "):"")):0}var N=function(){function e(e){this.groupSizes=new Uint32Array(512),this.length=512,this.tag=e}var t=e.prototype;return t.indexOfGroup=function(e){for(var t=0,n=0;n<e;n++)t+=this.groupSizes[n];return t},t.insertRules=function(e,t){if(e>=this.groupSizes.length){for(var n=this.groupSizes,r=n.length,o=r;e>=o;)(o<<=1)<0&&_(16,""+e);this.groupSizes=new Uint32Array(o),this.groupSizes.set(n),this.length=o;for(var s=r;s<o;s++)this.groupSizes[s]=0}for(var i=this.indexOfGroup(e+1),a=0,c=t.length;a<c;a++)this.tag.insertRule(i,t[a])&&(this.groupSizes[e]++,i++)},t.clearGroup=function(e){if(e<this.length){var t=this.groupSizes[e],n=this.indexOfGroup(e),r=n+t;this.groupSizes[e]=0;for(var o=n;o<r;o++)this.tag.deleteRule(n)}},t.getGroup=function(e){var t="";if(e>=this.length||0===this.groupSizes[e])return t;for(var n=this.groupSizes[e],r=this.indexOfGroup(e),o=r+n,s=r;s<o;s++)t+=this.tag.getRule(s)+"/*!sc*/\n";return t},e}(),C=new Map,A=new Map,I=1,P=function(e){if(C.has(e))return C.get(e);for(;A.has(I);)I++;var t=I++;return false&&0,C.set(e,t),A.set(t,e),t},x=function(e){return A.get(e)},O=function(e,t){t>=I&&(I=t+1),C.set(e,t),A.set(t,e)},R="style["+v+'][data-styled-version="5.3.6"]',D=new RegExp("^"+v+'\\.g(\\d+)\\[id="([\\w\\d-]+)"\\].*?"([^"]*)'),T=function(e,t,n){for(var r,o=n.split(","),s=0,i=o.length;s<i;s++)(r=o[s])&&e.registerName(t,r)},j=function(e,t){for(var n=(t.textContent||"").split("/*!sc*/\n"),r=[],o=0,s=n.length;o<s;o++){var i=n[o].trim();if(i){var a=i.match(D);if(a){var c=0|parseInt(a[1],10),u=a[2];0!==c&&(O(u,c),T(e,u,a[3]),e.getTag().insertRules(c,r)),r.length=0}else r.push(i)}}},k=function(){return true?__webpack_require__.nc:0},V=function(e){var t=document.head,n=e||t,r=document.createElement("style"),o=function(e){for(var t=e.childNodes,n=t.length;n>=0;n--){var r=t[n];if(r&&1===r.nodeType&&r.hasAttribute(v))return r}}(n),s=void 0!==o?o.nextSibling:null;r.setAttribute(v,"active"),r.setAttribute("data-styled-version","5.3.6");var i=k();return i&&r.setAttribute("nonce",i),n.insertBefore(r,s),r},M=function(){function e(e){var t=this.element=V(e);t.appendChild(document.createTextNode("")),this.sheet=function(e){if(e.sheet)return e.sheet;for(var t=document.styleSheets,n=0,r=t.length;n<r;n++){var o=t[n];if(o.ownerNode===e)return o}_(17)}(t),this.length=0}var t=e.prototype;return t.insertRule=function(e,t){try{return this.sheet.insertRule(t,e),this.length++,!0}catch(e){return!1}},t.deleteRule=function(e){this.sheet.deleteRule(e),this.length--},t.getRule=function(e){var t=this.sheet.cssRules[e];return void 0!==t&&"string"==typeof t.cssText?t.cssText:""},e}(),z=function(){function e(e){var t=this.element=V(e);this.nodes=t.childNodes,this.length=0}var t=e.prototype;return t.insertRule=function(e,t){if(e<=this.length&&e>=0){var n=document.createTextNode(t),r=this.nodes[e];return this.element.insertBefore(n,r||null),this.length++,!0}return!1},t.deleteRule=function(e){this.element.removeChild(this.nodes[e]),this.length--},t.getRule=function(e){return e<this.length?this.nodes[e].textContent:""},e}(),B=function(){function e(e){this.rules=[],this.length=0}var t=e.prototype;return t.insertRule=function(e,t){return e<=this.length&&(this.rules.splice(e,0,t),this.length++,!0)},t.deleteRule=function(e){this.rules.splice(e,1),this.length--},t.getRule=function(e){return e<this.length?this.rules[e]:""},e}(),q=g,G={isServer:!g,useCSSOMInjection:!S},L=function(){function e(e,t,n){void 0===e&&(e=p),void 0===t&&(t={}),this.options=u({},G,{},e),this.gs=t,this.names=new Map(n),this.server=!!e.isServer,!this.server&&g&&q&&(q=!1,function(e){for(var t=document.querySelectorAll(R),n=0,r=t.length;n<r;n++){var o=t[n];o&&"active"!==o.getAttribute(v)&&(j(e,o),o.parentNode&&o.parentNode.removeChild(o))}}(this))}e.registerId=function(e){return P(e)};var t=e.prototype;return t.reconstructWithOptions=function(t,n){return void 0===n&&(n=!0),new e(u({},this.options,{},t),this.gs,n&&this.names||void 0)},t.allocateGSInstance=function(e){return this.gs[e]=(this.gs[e]||0)+1},t.getTag=function(){return this.tag||(this.tag=(n=(t=this.options).isServer,r=t.useCSSOMInjection,o=t.target,e=n?new B(o):r?new M(o):new z(o),new N(e)));var e,t,n,r,o},t.hasNameForId=function(e,t){return this.names.has(e)&&this.names.get(e).has(t)},t.registerName=function(e,t){if(P(e),this.names.has(e))this.names.get(e).add(t);else{var n=new Set;n.add(t),this.names.set(e,n)}},t.insertRules=function(e,t,n){this.registerName(e,t),this.getTag().insertRules(P(e),n)},t.clearNames=function(e){this.names.has(e)&&this.names.get(e).clear()},t.clearRules=function(e){this.getTag().clearGroup(P(e)),this.clearNames(e)},t.clearTag=function(){this.tag=void 0},t.toString=function(){return function(e){for(var t=e.getTag(),n=t.length,r="",o=0;o<n;o++){var s=x(o);if(void 0!==s){var i=e.names.get(s),a=t.getGroup(o);if(i&&a&&i.size){var c=v+".g"+o+'[id="'+s+'"]',u="";void 0!==i&&i.forEach((function(e){e.length>0&&(u+=e+",")})),r+=""+a+c+'{content:"'+u+'"}/*!sc*/\n'}}}return r}(this)},e}(),F=/(a)(d)/gi,Y=function(e){return String.fromCharCode(e+(e>25?39:97))};function H(e){var t,n="";for(t=Math.abs(e);t>52;t=t/52|0)n=Y(t%52)+n;return(Y(t%52)+n).replace(F,"$1-$2")}var $=function(e,t){for(var n=t.length;n;)e=33*e^t.charCodeAt(--n);return e},W=function(e){return $(5381,e)};function U(e){for(var t=0;t<e.length;t+=1){var n=e[t];if(f(n)&&!y(n))return!1}return!0}var J=W("5.3.6"),X=function(){function e(e,t,n){this.rules=e,this.staticRulesId="",this.isStatic= true&&(void 0===n||n.isStatic)&&U(e),this.componentId=t,this.baseHash=$(J,t),this.baseStyle=n,L.registerId(t)}return e.prototype.generateAndInjectStyles=function(e,t,n){var r=this.componentId,o=[];if(this.baseStyle&&o.push(this.baseStyle.generateAndInjectStyles(e,t,n)),this.isStatic&&!n.hash)if(this.staticRulesId&&t.hasNameForId(r,this.staticRulesId))o.push(this.staticRulesId);else{var s=me(this.rules,e,t,n).join(""),i=H($(this.baseHash,s)>>>0);if(!t.hasNameForId(r,i)){var a=n(s,"."+i,void 0,r);t.insertRules(r,i,a)}o.push(i),this.staticRulesId=i}else{for(var c=this.rules.length,u=$(this.baseHash,n.hash),l="",d=0;d<c;d++){var h=this.rules[d];if("string"==typeof h)l+=h, false&&(0);else if(h){var p=me(h,e,t,n),f=Array.isArray(p)?p.join(""):p;u=$(u,f+d),l+=f}}if(l){var m=H(u>>>0);if(!t.hasNameForId(r,m)){var y=n(l,"."+m,void 0,r);t.insertRules(r,m,y)}o.push(m)}}return o.join(" ")},e}(),Z=/^\s*\/\/.*$/gm,K=[":","[",".","#"];function Q(e){var t,n,r,o,i=void 0===e?p:e,a=i.options,c=void 0===a?p:a,u=i.plugins,l=void 0===u?h:u,d=new s(c),f=[],m=function(e){function t(t){if(t)try{e(t+"}")}catch(e){}}return function(n,r,o,s,i,a,c,u,l,d){switch(n){case 1:if(0===l&&64===r.charCodeAt(0))return e(r+";"),"";break;case 2:if(0===u)return r+"/*|*/";break;case 3:switch(u){case 102:case 112:return e(o[0]+r),"";default:return r+(0===d?"/*|*/":"")}case-2:r.split("/*|*/}").forEach(t)}}}((function(e){f.push(e)})),y=function(e,r,s){return 0===r&&-1!==K.indexOf(s[n.length])||s.match(o)?e:"."+t};function v(e,s,i,a){void 0===a&&(a="&");var c=e.replace(Z,""),u=s&&i?i+" "+s+" { "+c+" }":c;return t=a,n=s,r=new RegExp("\\"+n+"\\b","g"),o=new RegExp("(\\"+n+"\\b){2,}"),d(i||!s?"":s,u)}return d.use([].concat(l,[function(e,t,o){2===e&&o.length&&o[0].lastIndexOf(n)>0&&(o[0]=o[0].replace(r,y))},m,function(e){if(-2===e){var t=f;return f=[],t}}])),v.hash=l.length?l.reduce((function(e,t){return t.name||_(15),$(e,t.name)}),5381).toString():"",v}var ee=r.createContext(),te=ee.Consumer,ne=r.createContext(),re=(ne.Consumer,new L),oe=Q();function se(){return n.useContext(ee)||re}function ie(){return n.useContext(ne)||oe}function ae(e){var t=n.useState(e.stylisPlugins),s=t[0],i=t[1],a=se(),c=n.useMemo((function(){var t=a;return e.sheet?t=e.sheet:e.target&&(t=t.reconstructWithOptions({target:e.target},!1)),e.disableCSSOMInjection&&(t=t.reconstructWithOptions({useCSSOMInjection:!1})),t}),[e.disableCSSOMInjection,e.sheet,e.target]),u=n.useMemo((function(){return Q({options:{prefix:!e.disableVendorPrefixes},plugins:s})}),[e.disableVendorPrefixes,s]);return n.useEffect((function(){o(s,e.stylisPlugins)||i(e.stylisPlugins)}),[e.stylisPlugins]),r.createElement(ee.Provider,{value:c},r.createElement(ne.Provider,{value:u}, false?0:e.children))}var ce=function(){function e(e,t){var n=this;this.inject=function(e,t){void 0===t&&(t=oe);var r=n.name+t.hash;e.hasNameForId(n.id,r)||e.insertRules(n.id,r,t(n.rules,r,"@keyframes"))},this.toString=function(){return _(12,String(n.name))},this.name=e,this.id="sc-keyframes-"+e,this.rules=t}return e.prototype.getName=function(e){return void 0===e&&(e=oe),this.name+e.hash},e}(),ue=/([A-Z])/,le=/([A-Z])/g,de=/^ms-/,he=function(e){return"-"+e.toLowerCase()};function pe(e){return ue.test(e)?e.replace(le,he).replace(de,"-ms-"):e}var fe=function(e){return null==e||!1===e||""===e};function me(e,n,r,o){if(Array.isArray(e)){for(var s,a=[],c=0,u=e.length;c<u;c+=1)""!==(s=me(e[c],n,r,o))&&(Array.isArray(s)?a.push.apply(a,s):a.push(s));return a}if(fe(e))return"";if(y(e))return"."+e.styledComponentId;if(f(e)){if("function"!=typeof(h=e)||h.prototype&&h.prototype.isReactComponent||!n)return e;var l=e(n);return false&&0,me(l,n,r,o)}var h;return e instanceof ce?r?(e.inject(r,o),e.getName(o)):e:d(e)?function e(t,n){var r,o,s=[];for(var a in t)t.hasOwnProperty(a)&&!fe(t[a])&&(Array.isArray(t[a])&&t[a].isCss||f(t[a])?s.push(pe(a)+":",t[a],";"):d(t[a])?s.push.apply(s,e(t[a],a)):s.push(pe(a)+": "+(r=a,null==(o=t[a])||"boolean"==typeof o||""===o?"":"number"!=typeof o||0===o||r in i?String(o).trim():o+"px")+";"));return n?[n+" {"].concat(s,["}"]):s}(e):e.toString()}var ye=function(e){return Array.isArray(e)&&(e.isCss=!0),e};function ve(e){for(var t=arguments.length,n=new Array(t>1?t-1:0),r=1;r<t;r++)n[r-1]=arguments[r];return f(e)||d(e)?ye(me(l(h,[e].concat(n)))):0===n.length&&1===e.length&&"string"==typeof e[0]?e:ye(me(l(e,n)))}var ge=/invalid hook call/i,Se=new Set,we=function(e,t){if(false){ var s, r, o; }},Ee=function(e,t,n){return void 0===n&&(n=p),e.theme!==n.theme&&e.theme||t||n.theme},be=/[!"#$%&'()*+,./:;<=>?@[\\\]^`{|}~-]+/g,_e=/(^-|-$)/g;function Ne(e){return e.replace(be,"-").replace(_e,"")}var Ce=function(e){return H(W(e)>>>0)};function Ae(e){return"string"==typeof e&&( true||0)}var Ie=function(e){return"function"==typeof e||"object"==typeof e&&null!==e&&!Array.isArray(e)},Pe=function(e){return"__proto__"!==e&&"constructor"!==e&&"prototype"!==e};function xe(e,t,n){var r=e[n];Ie(t)&&Ie(r)?Oe(r,t):e[n]=t}function Oe(e){for(var t=arguments.length,n=new Array(t>1?t-1:0),r=1;r<t;r++)n[r-1]=arguments[r];for(var o=0,s=n;o<s.length;o++){var i=s[o];if(Ie(i))for(var a in i)Pe(a)&&xe(e,i[a],a)}return e}var Re=r.createContext(),De=Re.Consumer,Te={};function je(e,t,o){var s=y(e),i=!Ae(e),l=t.attrs,d=void 0===l?h:l,v=t.componentId,g=void 0===v?function(e,t){var n="string"!=typeof e?"sc":Ne(e);Te[n]=(Te[n]||0)+1;var r=n+"-"+Ce("5.3.6"+n+Te[n]);return t?t+"-"+r:r}(t.displayName,t.parentComponentId):v,S=t.displayName,w=void 0===S?function(e){return Ae(e)?"styled."+e:"Styled("+m(e)+")"}(e):S,E=t.displayName&&t.componentId?Ne(t.displayName)+"-"+t.componentId:t.componentId||g,b=s&&e.attrs?Array.prototype.concat(e.attrs,d).filter(Boolean):d,_=t.shouldForwardProp;s&&e.shouldForwardProp&&(_=t.shouldForwardProp?function(n,r,o){return e.shouldForwardProp(n,r,o)&&t.shouldForwardProp(n,r,o)}:e.shouldForwardProp);var N,C=new X(o,E,s?e.componentStyle:void 0),A=C.isStatic&&0===d.length,I=function(e,t){return function(e,t,r,o){var s=e.attrs,i=e.componentStyle,c=e.defaultProps,l=e.foldedComponentIds,d=e.shouldForwardProp,h=e.styledComponentId,m=e.target; false&&0;var y=function(e,t,n){void 0===e&&(e=p);var r=u({},t,{theme:e}),o={};return n.forEach((function(e){var t,n,s,i=e;for(t in f(i)&&(i=i(r)),i)r[t]=o[t]="className"===t?(n=o[t],s=i[t],n&&s?n+" "+s:n||s):i[t]})),[r,o]}(Ee(t,n.useContext(Re),c)||p,t,s),v=y[0],g=y[1],S=function(e,t,r,o){var s=se(),i=ie(),a=t?e.generateAndInjectStyles(p,s,i):e.generateAndInjectStyles(r,s,i);return false&&0, false&&0,a}(i,o,v, false?0:void 0),w=r,E=g.$as||t.$as||g.as||t.as||m,b=Ae(E),_=g!==t?u({},t,{},g):t,N={};for(var C in _)"$"!==C[0]&&"as"!==C&&("forwardedAs"===C?N.as=_[C]:(d?d(C,a,E):!b||a(C))&&(N[C]=_[C]));return t.style&&g.style!==t.style&&(N.style=u({},t.style,{},g.style)),N.className=Array.prototype.concat(l,h,S!==h?S:null,t.className,g.className).filter(Boolean).join(" "),N.ref=w,n.createElement(E,N)}(N,e,t,A)};return I.displayName=w,(N=r.forwardRef(I)).attrs=b,N.componentStyle=C,N.displayName=w,N.shouldForwardProp=_,N.foldedComponentIds=s?Array.prototype.concat(e.foldedComponentIds,e.styledComponentId):h,N.styledComponentId=E,N.target=s?e.target:e,N.withComponent=function(e){var n=t.componentId,r=function(e,t){if(null==e)return{};var n,r,o={},s=Object.keys(e);for(r=0;r<s.length;r++)n=s[r],t.indexOf(n)>=0||(o[n]=e[n]);return o}(t,["componentId"]),s=n&&n+"-"+(Ae(e)?e:Ne(m(e)));return je(e,u({},r,{attrs:b,componentId:s}),o)},Object.defineProperty(N,"defaultProps",{get:function(){return this._foldedDefaultProps},set:function(t){this._foldedDefaultProps=s?Oe({},e.defaultProps,t):t}}), false&&(0),N.toString=function(){return"."+N.styledComponentId},i&&c(N,e,{attrs:!0,componentStyle:!0,displayName:!0,foldedComponentIds:!0,shouldForwardProp:!0,styledComponentId:!0,target:!0,withComponent:!0}),N}var ke=function(e){return function e(n,r,o){if(void 0===o&&(o=p),!t.isValidElementType(r))return _(1,String(r));var s=function(){return n(r,o,ve.apply(void 0,arguments))};return s.withConfig=function(t){return e(n,r,u({},o,{},t))},s.attrs=function(t){return e(n,r,u({},o,{attrs:Array.prototype.concat(o.attrs,t).filter(Boolean)}))},s}(je,e)};["a","abbr","address","area","article","aside","audio","b","base","bdi","bdo","big","blockquote","body","br","button","canvas","caption","cite","code","col","colgroup","data","datalist","dd","del","details","dfn","dialog","div","dl","dt","em","embed","fieldset","figcaption","figure","footer","form","h1","h2","h3","h4","h5","h6","head","header","hgroup","hr","html","i","iframe","img","input","ins","kbd","keygen","label","legend","li","link","main","map","mark","marquee","menu","menuitem","meta","meter","nav","noscript","object","ol","optgroup","option","output","p","param","picture","pre","progress","q","rp","rt","ruby","s","samp","script","section","select","small","source","span","strong","style","sub","summary","sup","table","tbody","td","textarea","tfoot","th","thead","time","title","tr","track","u","ul","var","video","wbr","circle","clipPath","defs","ellipse","foreignObject","g","image","line","linearGradient","marker","mask","path","pattern","polygon","polyline","radialGradient","rect","stop","svg","text","textPath","tspan"].forEach((function(e){ke[e]=ke(e)}));var Ve=function(){function e(e,t){this.rules=e,this.componentId=t,this.isStatic=U(e),L.registerId(this.componentId+1)}var t=e.prototype;return t.createStyles=function(e,t,n,r){var o=r(me(this.rules,t,n,r).join(""),""),s=this.componentId+e;n.insertRules(s,s,o)},t.removeStyles=function(e,t){t.clearRules(this.componentId+e)},t.renderStyles=function(e,t,n,r){e>2&&L.registerId(this.componentId+e),this.removeStyles(e,n),this.createStyles(e,t,n,r)},e}(),Me=/^\s*<\/[a-z]/i,ze=function(){function e(){var e=this;this._emitSheetCSS=function(){var t=e.instance.toString();if(!t)return"";var n=k();return"<style "+[n&&'nonce="'+n+'"',v+'="true"','data-styled-version="5.3.6"'].filter(Boolean).join(" ")+">"+t+"</style>"},this.getStyleTags=function(){return e.sealed?_(2):e._emitSheetCSS()},this.getStyleElement=function(){var t;if(e.sealed)return _(2);var n=((t={})[v]="",t["data-styled-version"]="5.3.6",t.dangerouslySetInnerHTML={__html:e.instance.toString()},t),o=k();return o&&(n.nonce=o),[r.createElement("style",u({},n,{key:"sc-0-0"}))]},this.seal=function(){e.sealed=!0},this.instance=new L({isServer:!0}),this.sealed=!1}var t=e.prototype;return t.collectStyles=function(e){return this.sealed?_(2):r.createElement(ae,{sheet:this.instance},e)},t.interleaveWithNodeStream=function(e){if(g)return _(3);if(this.sealed)return _(2);this.seal();var t=__webpack_require__(2781),n=(t.Readable,t.Transform),r=e,o=this.instance,s=this._emitSheetCSS,i=new n({transform:function(e,t,n){var r=e.toString(),i=s();if(o.clearTag(),Me.test(r)){var a=r.indexOf(">")+1,c=r.slice(0,a),u=r.slice(a);this.push(c+i+u)}else this.push(i+r);n()}});return r.on("error",(function(e){i.emit("error",e)})),r.pipe(i)},e}(),Be={StyleSheet:L,masterSheet:re}; false&&0, false&&(0),__webpack_unused_export__=ze,__webpack_unused_export__=te,__webpack_unused_export__=ee,__webpack_unused_export__=ae,__webpack_unused_export__=De,__webpack_unused_export__=Re,__webpack_unused_export__=function(e){var t=n.useContext(Re),o=n.useMemo((function(){return function(e,t){if(!e)return _(14);if(f(e)){var n=e(t);return true?n:0}return Array.isArray(e)||"object"!=typeof e?_(8):t?u({},t,{},e):e}(e.theme,t)}),[e.theme,t]);return e.children?r.createElement(Re.Provider,{value:o},e.children):null},__webpack_unused_export__=Be,__webpack_unused_export__=function(e){for(var t=arguments.length,o=new Array(t>1?t-1:0),s=1;s<t;s++)o[s-1]=arguments[s];var i=ve.apply(void 0,[e].concat(o)),a="sc-global-"+Ce(JSON.stringify(i)),c=new Ve(i,a);function l(e){var t=se(),o=ie(),s=n.useContext(Re),c=n.useRef(t.allocateGSInstance(a)).current;return false&&0, false&&0,t.server&&d(c,e,t,s,o),null}function d(e,t,n,r,o){if(c.isStatic)c.renderStyles(e,w,n,o);else{var s=u({},t,{theme:Ee(t,r,l.defaultProps)});c.renderStyles(e,s,n,o)}}return false&&0,r.memo(l)},__webpack_unused_export__=ve,exports.ZP=ke,__webpack_unused_export__=y,__webpack_unused_export__=function(e){ false&&0;for(var t=arguments.length,n=new Array(t>1?t-1:0),r=1;r<t;r++)n[r-1]=arguments[r];var o=ve.apply(void 0,[e].concat(n)).join(""),s=Ce(o);return new ce(s,o)},__webpack_unused_export__=function(){return n.useContext(Re)},__webpack_unused_export__="5.3.6",__webpack_unused_export__=function(e){var t=r.forwardRef((function(t,o){var s=n.useContext(Re),i=e.defaultProps,a=Ee(t,s,i);return false&&0,r.createElement(e,u({},t,{theme:a,ref:o}))}));return c(t,e),t.displayName="WithTheme("+m(e)+")",t};
//# sourceMappingURL=styled-components.cjs.js.map


/***/ })

};
;