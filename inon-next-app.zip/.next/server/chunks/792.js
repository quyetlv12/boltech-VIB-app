exports.id = 792;
exports.ids = [792];
exports.modules = {

/***/ 1066:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9793))

/***/ }),

/***/ 6529:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 9446, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3258, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6862, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 2030, 23))

/***/ }),

/***/ 4914:
/***/ (() => {



/***/ }),

/***/ 447:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Head)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8499);

function Head() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                children: "InOn"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                content: "width=device-width, initial-scale=1",
                name: "viewport"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "description",
                content: "InOn App"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                rel: "icon",
                href: "/favicon.ico"
            })
        ]
    });
}


/***/ }),

/***/ 8514:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ */ const { createProxy  } = __webpack_require__(4353);
module.exports = createProxy("F:\\INON\\inon-next-app\\app\\layout.tsx");


/***/ }),

/***/ 9793:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ RootLayout)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./constants/index.ts + 9 modules
var constants = __webpack_require__(8451);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(9483);
;// CONCATENATED MODULE: ./assests/header/arrow-active.png
/* harmony default export */ const arrow_active = ({"src":"/_next/static/media/arrow-active.23f05af3.png","height":40,"width":40,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAflBMVEUALBUOISINHyERGyUQGiURGSYRGSUSGCYRGCYRGCURFyYRFyUPFiQPFSkPFCkQFCQPEyQLCS4AAAASGCYRGCYSFiYSFiUSFiQSGCYRGCYRGCURFyURGCYRFyYRGCQRFiUSGCURFyYRGCYSFyURGCURGCURGCURFyURGCURFyUqjYL1AAAAKnRSTlMAAAAAAAAAAAAAAAAAAAAAAAAAAQEBAQECAgICAwMIFjU2RkpZWnJ2orDiLPoLAAAARklEQVR42gVAhRGAMBAL2sDjTktx3X9BDiR1mpUVAvaR1ST8Tq5ZRsLGz7tvbDDx/o5V1UAr5yJGwXXaaDCiEHqeLvKk+gGjSwR3iNrNsgAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./assests/header/arrow-not-active.png
/* harmony default export */ const arrow_not_active = ({"src":"/_next/static/media/arrow-not-active.4235032d.png","height":40,"width":40,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAa0lEQVR42mNABxev3mQC0ZgSV24xXbxykxnEvnT5NiOa5E0mKM0BxJEg9uUrdxhhOhmhtBkQuwEVLAZaUwqx7hYzwyWogktXb5kCsRdQwQYgLoK6hxndCjGoFUANaO4A6ma6DHQouiRBbwIARHJKEvBHr/QAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./assests/header/close.png
/* harmony default export */ const header_close = ({"src":"/_next/static/media/close.a98aca32.png","height":40,"width":40,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAANElEQVR42mMAAyYGRiBkYmAAAyATmQUWt2KQAEIrMA8sKsEwj2EugwQDkIchgKEFw1AMawEd5AQ7UUe1AAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./assests/header/reload.png
/* harmony default export */ const reload = ({"src":"/_next/static/media/reload.3214d955.png","height":40,"width":40,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAATElEQVR42mXNIQ5AYBgA0OfLuguopkk2tzAn8Af7gwOYaqqTuKFkgvrKgwJAACxWs+qjW9K4VBAGQCcBhwC1DIwySqf2PSabXY/4tQ82dAhl6lR9ZwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./store/buyInsurance.ts
var buyInsurance = __webpack_require__(227);
;// CONCATENATED MODULE: ./components/ProcessBuyInsurance.tsx



const ProcessBuyInsurance = ()=>{
    const step = (0,constants/* useAppSelector */.CG)(buyInsurance/* getStep */.TO);
    const maxStep = (0,constants/* useAppSelector */.CG)(buyInsurance/* getMaxStep */.aK);
    console.log("step", step);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "px-3 py-1",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: `bg-[#E5E7EB] rounded-md h-[5px] w-full transition-all border-0 outline-0 duration-200 ${step > 0 ? "flex" : "hidden"}`,
            children: constants/* stepArray.map */.Lw.map((_elt, index)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: `bg-[${step >= _elt ? `#000` : `#fff`}] h-[5px] w-1/3 border-l-1 outline-0 border-[#000]`
                }, index))
        })
    });
};
/* harmony default export */ const components_ProcessBuyInsurance = (ProcessBuyInsurance);

;// CONCATENATED MODULE: ./components/Header.tsx











const Header = ()=>{
    const pathName = (0,navigation.usePathname)() || "/";
    const router = (0,navigation.useRouter)();
    const dispatch = (0,constants/* useAppDispatch */.TL)();
    const step = (0,constants/* useAppSelector */.CG)(buyInsurance/* getStep */.TO);
    const step0data = (0,constants/* useAppSelector */.CG)(buyInsurance/* getStep0data */.fx);
    const inputStatus = (0,constants/* useAppSelector */.CG)(buyInsurance/* getInputStatus */.Rv);
    const inputData = (0,constants/* useAppSelector */.CG)(buyInsurance/* getInputData */.v7);
    const handleBack = ()=>{
        if (step > 0) {
            dispatch((0,buyInsurance/* backStep */.HY)());
            return;
        } else if (step === 1) {
            router.push("/buyInsurance");
        }
        router.back();
    };
    const handleReload = ()=>{
        router.refresh();
    };
    const handleNext = ()=>{
        dispatch((0,buyInsurance/* nextStep */.zF)());
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: inputStatus ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: `h-[50px] flex-col fixed top-0 z-40 w-full bg-[#fff] ${(0,constants/* isHiddenHeader */.th)(pathName)}`,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex items-center h-[50px] gap-10 justify-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "font-medium text-[16px]",
                        children: inputData.content
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "absolute right-[2%]",
                        onClick: ()=>dispatch((0,buyInsurance/* turnOffInput */.cQ)()),
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: header_close,
                            alt: "close app",
                            className: "w-[35px] h-[35px]"
                        })
                    })
                ]
            })
        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: `h-[50px] flex-col fixed top-0 z-40 w-full  bg-[#fff] ${(0,constants/* isHiddenHeader */.th)(pathName)}`,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex items-center justify-between w-full px-3 h-[50px]",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: "",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: header_close,
                                    alt: "close app",
                                    className: "w-[35px] h-[35px]"
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                onClick: handleBack,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: arrow_active,
                                    alt: "close app",
                                    className: "w-[35px] h-[35px]"
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "font-medium text-[16px]",
                            children: step0data?.name
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            onClick: handleNext,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: arrow_not_active,
                                alt: "next",
                                className: "w-[35px] h-[35px]"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            onClick: handleReload,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: reload,
                                alt: "reload app",
                                className: "w-[35px] h-[35px]"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(components_ProcessBuyInsurance, {})
            ]
        })
    });
};
/* harmony default export */ const components_Header = (Header);

// EXTERNAL MODULE: ./app/globals.css
var globals = __webpack_require__(1338);
// EXTERNAL MODULE: ./node_modules/react-redux/lib/index.js
var lib = __webpack_require__(1560);
// EXTERNAL MODULE: ./node_modules/@reduxjs/toolkit/dist/redux-toolkit.cjs.production.min.js
var redux_toolkit_cjs_production_min = __webpack_require__(668);
// EXTERNAL MODULE: ./node_modules/lodash/lodash.js
var lodash = __webpack_require__(5089);
var lodash_default = /*#__PURE__*/__webpack_require__.n(lodash);
// EXTERNAL MODULE: ./node_modules/redux-batched-subscribe/lib/index.js
var redux_batched_subscribe_lib = __webpack_require__(7061);
// EXTERNAL MODULE: ./node_modules/redux-logger/dist/redux-logger.js
var redux_logger = __webpack_require__(5870);
// EXTERNAL MODULE: ./node_modules/redux-persist/lib/index.js
var redux_persist_lib = __webpack_require__(7698);
// EXTERNAL MODULE: ./node_modules/redux-persist/lib/storage/index.js
var storage = __webpack_require__(5292);
;// CONCATENATED MODULE: ./store/app.ts

const initialState = {
    isLoading: false,
    auth: null
};
const appSlice = (0,redux_toolkit_cjs_production_min.createSlice)({
    name: "app",
    initialState,
    reducers: {
        showLoading (state) {
            state.isLoading = true;
        },
        hideLoading (state) {
            state.isLoading = false;
        }
    }
});
const { showLoading , hideLoading  } = appSlice.actions;
/* harmony default export */ const app = (appSlice.reducer);

;// CONCATENATED MODULE: ./store/index.ts









const rootReducer = (0,redux_toolkit_cjs_production_min.combineReducers)({
    app: app,
    buyInsurance: buyInsurance/* default */.ZP
});
const persistConfig = {
    key: "root",
    storage: storage/* default */.Z
};
const debounceNotify = lodash_default().debounce((notify)=>notify());
const persistedReducer = (0,redux_persist_lib.persistReducer)(persistConfig, rootReducer);
function makeStore() {
    return (0,redux_toolkit_cjs_production_min.configureStore)({
        reducer: persistedReducer,
        devTools: true,
        middleware:  false ? 0 : undefined,
        enhancers: [
            (0,redux_batched_subscribe_lib/* batchedSubscribe */.S)(debounceNotify)
        ]
    });
}
const store = makeStore();

// EXTERNAL MODULE: ./node_modules/redux-persist/lib/integration/react.js
var react = __webpack_require__(7370);
;// CONCATENATED MODULE: ./app/provider.tsx





function Providers({ children  }) {
    let persistor = (0,redux_persist_lib.persistStore)(store);
    return /*#__PURE__*/ jsx_runtime_.jsx(lib.Provider, {
        store: store,
        children: /*#__PURE__*/ jsx_runtime_.jsx(react/* PersistGate */.r, {
            loading: null,
            persistor: persistor,
            children: children
        })
    });
}

;// CONCATENATED MODULE: ./app/layout.tsx





function RootLayout({ children  }) {
    const pathName = (0,navigation.usePathname)() || "/";
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("html", {
        lang: "en",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("head", {}),
            /*#__PURE__*/ jsx_runtime_.jsx("body", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Providers, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(components_Header, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: `${pathName === "/" ? "" : "pt-[50px] pb-[30px] bg-light-gray w-full min-h-screen mx-auto"}`,
                            children: children
                        })
                    ]
                })
            })
        ]
    });
}


/***/ }),

/***/ 8451:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "zJ": () => (/* binding */ APPLY),
  "HV": () => (/* binding */ BUY_NOW),
  "zp": () => (/* binding */ BUY_ONLINE),
  "zE": () => (/* binding */ COUNTINUE),
  "OV": () => (/* binding */ INPUT_NUMBER_TYPE),
  "s9": () => (/* binding */ INPUT_SELECT_TYPE),
  "bQ": () => (/* binding */ PRODUCTS),
  "Bh": () => (/* binding */ SELECT_PACKAGE),
  "hv": () => (/* binding */ TEXT_FOOTER_COLOR),
  "th": () => (/* binding */ isHiddenHeader),
  "nK": () => (/* binding */ isObjectEmpty),
  "Lw": () => (/* binding */ stepArray),
  "TL": () => (/* binding */ useAppDispatch),
  "CG": () => (/* binding */ useAppSelector)
});

// UNUSED EXPORTS: AGREE, API_TIME_OUT, CAR, CARTNDS, DOMESTIC, HEATH_CARE, HOME, INPUT_DATE_TYPE, INPUT_STRING_TYPE, PATH_HOME, checkUndefineImage, isShowInput

;// CONCATENATED MODULE: ./assests/products/car.png
/* harmony default export */ const car = ({"src":"/_next/static/media/car.9daa292f.png","height":22,"width":28,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAAlklEQVR42h3JvQ4BURRF4XUmo5BQ6yXTq/VCPw9DQTKFTqHGS+g13kGhkCh0o8b8xL3biWJn5cs2AG2zoVodqTSgAl9pjXLb3W8WD9mYl1Y0zKgEFfxbc+KtIuWrJeZnpEV0kABa94SEkBK4YnwIugAF0XCv3SPvI3X1HbljSgQA99zdI9o+RSqBM4EFRtckkVB7NsDzB9YDSLXn7az/AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./assests/products/carTNDS.png
/* harmony default export */ const carTNDS = ({"src":"/_next/static/media/carTNDS.4f608f15.png","height":22,"width":28,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAA0UlEQVR4nAHGADn/Af6hUAQA9/H8AOG/AABxynoB9/lV//X5DQD+AZAA/P6UAf6VIAAA/hgfAPwKVgEVMzj/EBzmACcxRwD5/CUA+/+FAf2fMzUB6c2fAPoWKwHw6gD/3QD1AC9ThgBRZ0cAAQQMAf2YI7gBDEFHAebc9wDr1wL/G1MHAMuY2gBkqLUAExZFAf2TApwBIoRjAd3QAP/eqgAANooAAM7D3ABLXX0AExcmAf6WK6oA7NUUAfUAuf8AKwcA1dUUABEWTwCj6icAuqb4xidQxwdwWOgAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./assests/products/heathCare.png
/* harmony default export */ const heathCare = ({"src":"/_next/static/media/heathCare.11ab0527.png","height":20,"width":24,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAApUlEQVR42g3JMS5EYRSG4ef8uQq9RHSKsQ1qK5hKI1ZjA1MqdNagldiARkMzoUKQGXdy73+c6v3yPdFXJ0u7vLHNLzvnvs0m9za5H6OL6KvFu9FhHapvtqp5ZEP1daAwdYIsgK6DjOOme0ArnKWsJmprIR+bnpe6D+xJk1Sott/kqvlrz3qcyVijIAZpHZy225en6NeLwdgmHNjOd8ac/OQyxCeGf8YyVqnulrM3AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./assests/products/domestic.png
/* harmony default export */ const domestic = ({"src":"/_next/static/media/domestic.f6a604b6.png","height":28,"width":28,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA1UlEQVR42k3PO2pCYRAF4D+PLi4ghKS4M1NkE/ZpUqSLIIKPK6hYiA+0UEEUbUS9iAiigo2VlYuxsBELN6Gc8feK6OmG+RjmmEsw4PfT8OvFPERdmiJCa4OxBDGQIzq8Q50XKHMYWVrCJdWIMzM6kQD6EkVb9hYoSqQWqAUr8xg0vl9R4w2KFmUsSFL4uhjJLzz5R5PnqLKiwDsfuDS7AQ89UbRYLVhpngJI0wFx2t7Pd6WCpg9C/pyiBGKkGnI+zSlHT9cf2EON/vyKaX5D1PnR4MfzGcPkbSKGNz9AAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./assests/banner/car.png
/* harmony default export */ const banner_car = ({"src":"/_next/static/media/car.60f57783.png","height":90,"width":108,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAAqUlEQVR4nBWPMQrCQBRE54OCpScQLOzs7AyktLHyFh5CBb2DJAewtvACCiqWKawEUcgFLGxSJLt5n2V25s8Mn10Ln0yKlioqVVAJBAbMN/hi4ZvNKUwYdsBDqQFRa3ThhSOFBeYTo0sQ4YYzRp0o5CuMPkOCeYd9wxR+wD8vFBQq8AZXAiNI0CPQ88IBUYItoa/3Df6WDRjyi/yFfcZaymJHf5RZzb3Hn7XKP1el7jrGzgAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":7});
// EXTERNAL MODULE: ./node_modules/lodash/lodash.js
var lodash = __webpack_require__(5089);
var lodash_default = /*#__PURE__*/__webpack_require__.n(lodash);
;// CONCATENATED MODULE: ./assests/products/home.png
/* harmony default export */ const home = ({"src":"/_next/static/media/home.92e0b08f.png","height":24,"width":24,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAvUlEQVR42j2MPQrCQBSE58UoXsP8NII2egFP4QGClWAvFhYiVkI68ecAHsPKC1iJSI6RxMA+563gLm9nZ+bbhcuTlqrCxq3jnVtG27/PopZ4k6cTVJqjwpADlPqgLuT4vok7pBeWGUqAWrNQate81HoikDCAYxCwsNegp8JJpUFIvuG0ofokdoZIwPsMQEq0CQEoN1jcZfPaw4J53DfAGvuh4wGnY10lU3y8G9kp7EI4FAB6DAYQXAnCr58UX/Q4aKBKL6KLAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./node_modules/react-redux/lib/index.js
var lib = __webpack_require__(1560);
;// CONCATENATED MODULE: ./assests/iconStep0/carBen1.png
/* harmony default export */ const carBen1 = ({"src":"/_next/static/media/carBen1.50df1a3a.png","height":32,"width":34,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAzUlEQVR42g3Kvy4EUQBG8fPNv0gUEj2N0VJ4hS23oFVoPIM38ACbCN5AIhIVjYhWIxKJmppKYuydu7NzP7f65SRHadbWwEDQGjFd0ZMUlofAr0NZC2CcbW0r6JHemwTIfiowAT40XrZTRW7picz9moXgvWxJ7wOlizawYKDjiIV3CJjoN+ZcE0kVZgVxjjkGphiAG5Y+w5xUwBej3yn0TNIpMiQ2cjeyvyugI2mdIk+rvNAIda4RuzZdgWmoeWDQPn/c8eN7l0zc8yRU/wO79mGWWStvXwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./assests/iconStep0/carBen2.png
/* harmony default export */ const carBen2 = ({"src":"/_next/static/media/carBen2.17eb1acf.png","height":35,"width":34,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAt0lEQVR42gXAvyqFYRgA8N/z+o7OYlBWgz/XIGVUSnIBLsCi3IGsFmV2BzYpnRKFjUWS+dglDAY63/s+inayVLLX4oOYgOXM3PCZ90psd0SLzo7Z3MtfD3401SrxpjrqDMzpHUi7IsbkomrfwMhfXhTFMUI61OetKSuaZ4hwVrBlyrqMwIs0lqYl0rCTbkw8klUDT1IFqRXNuWYel9HHQkScCl+aO8x0xBW5idd8rwzjG9fCmhajfxPpTUz2WK6bAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./assests/iconStep0/carBen3.png
/* harmony default export */ const carBen3 = ({"src":"/_next/static/media/carBen3.bcca83b8.png","height":41,"width":40,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA10lEQVR42g3NPy9DcRTH4c85+VUZrB3UUNpBMEsMgpi9By/CbjGxs9nEYrNLbEYSCYmkxeCGGPy596q293x1fKbH4rjjDBRAk5Jlcpy+bvnlFXDXDKGW1Um2jvGO0+WPLYIVP+qG24e17Ildfrgn15CKJRrWo2QzduaaCbGG2CeYZcLeKKhRaNr6ulKNxUTwiAB0zqQ9kykjp1DdNmzElPOtayouGXLKSyww0IlVWsVoyPWQzB1gW1GdjYsLSoG4oa1D3+uNLA46TqngUwBt+2J+7DsSGeD/3yBhxoq9bL8AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./constants/index.ts











const API_TIME_OUT = 10000;
const CAR = "car";
const CARTNDS = "carTnds";
const HOME = "home";
const HEATH_CARE = "heathCare";
const DOMESTIC = "domestic";
const useAppDispatch = ()=>(0,lib.useDispatch)();
const useAppSelector = lib.useSelector;
// ==============COLOR==============
const TEXT_FOOTER_COLOR = "#6C727F";
const PATH_HOME = "/";
// ====================================
const PRODUCTS = [
    {
        name: "Bảo hiểm Xe \xd4t\xf4",
        icon: car,
        type: CAR,
        slogan: "Bảo vệ tối ưu cho xe \xf4 t\xf4 của bạn khỏi những thiệt hại vật chất do thi\xean tai, tai nạn bất ngờ kh\xf4ng lường trước được, gi\xfap bạn an t\xe2m tr\xean mọi nẻo đường",
        benefit: [
            {
                icon: carBen1,
                content: "Hệ thống gara xe bảo h\xe0nh tr\xean to\xe0n quốc"
            },
            {
                icon: carBen2,
                content: "Dịch vụ gi\xe1m định nhanh ch\xf3ng, ch\xednh x\xe1c v\xe0 thuận tiện"
            },
            {
                icon: carBen3,
                content: "Hỗ trợ cứu hộ 24/7"
            }
        ],
        link: "/buyInsurance/car",
        logo: banner_car
    },
    {
        name: "Bảo hiểm Tr\xe1ch nhiệm d\xe2n sự \xd4t\xf4",
        icon: carTNDS,
        type: CAR,
        slogan: "Bảo vệ tối ưu cho xe \xf4 t\xf4 của bạn khỏi những thiệt hại vật chất do thi\xean tai, tai nạn bất ngờ kh\xf4ng lường trước được, gi\xfap bạn an t\xe2m tr\xean mọi nẻo đường",
        benefit: [
            {
                icon: carBen1,
                content: "Hệ thống gara xe bảo h\xe0nh tr\xean to\xe0n quốc"
            },
            {
                icon: carBen2,
                content: "Dịch vụ gi\xe1m định nhanh ch\xf3ng, ch\xednh x\xe1c v\xe0 thuận tiện"
            },
            {
                icon: carBen3,
                content: "Hỗ trợ cứu hộ 24/7"
            }
        ],
        link: "/buyInsurance"
    },
    {
        name: "Bảo hiểm Nh\xe0",
        icon: home,
        type: HOME,
        slogan: "Bảo vệ tối ưu cho xe \xf4 t\xf4 của bạn khỏi những thiệt hại vật chất do thi\xean tai, tai nạn bất ngờ kh\xf4ng lường trước được, gi\xfap bạn an t\xe2m tr\xean mọi nẻo đường",
        benefit: [
            {
                icon: carBen1,
                content: "Hệ thống gara xe bảo h\xe0nh tr\xean to\xe0n quốc"
            },
            {
                icon: carBen2,
                content: "Dịch vụ gi\xe1m định nhanh ch\xf3ng, ch\xednh x\xe1c v\xe0 thuận tiện"
            },
            {
                icon: carBen3,
                content: "Hỗ trợ cứu hộ 24/7"
            }
        ],
        link: "/buyInsurance"
    },
    {
        name: "Bảo hiểm Sức Khoẻ",
        icon: heathCare,
        type: HEATH_CARE,
        slogan: "Bảo vệ tối ưu cho xe \xf4 t\xf4 của bạn khỏi những thiệt hại vật chất do thi\xean tai, tai nạn bất ngờ kh\xf4ng lường trước được, gi\xfap bạn an t\xe2m tr\xean mọi nẻo đường",
        benefit: [
            {
                icon: carBen1,
                content: "Hệ thống gara xe bảo h\xe0nh tr\xean to\xe0n quốc"
            },
            {
                icon: carBen2,
                content: "Dịch vụ gi\xe1m định nhanh ch\xf3ng, ch\xednh x\xe1c v\xe0 thuận tiện"
            },
            {
                icon: carBen3,
                content: "Hỗ trợ cứu hộ 24/7"
            }
        ],
        link: "/buyInsurance"
    },
    {
        name: "Bảo hiểm Du lịch Quốc tế",
        icon: domestic,
        type: DOMESTIC,
        slogan: "Bảo vệ tối ưu cho xe \xf4 t\xf4 của bạn khỏi những thiệt hại vật chất do thi\xean tai, tai nạn bất ngờ kh\xf4ng lường trước được, gi\xfap bạn an t\xe2m tr\xean mọi nẻo đường",
        benefit: [
            {
                icon: carBen1,
                content: "Hệ thống gara xe bảo h\xe0nh tr\xean to\xe0n quốc"
            },
            {
                icon: carBen2,
                content: "Dịch vụ gi\xe1m định nhanh ch\xf3ng, ch\xednh x\xe1c v\xe0 thuận tiện"
            },
            {
                icon: carBen3,
                content: "Hỗ trợ cứu hộ 24/7"
            }
        ],
        link: "/buyInsurance"
    }
];
const checkUndefineImage = (image)=>image !== undefined ? image : "";
const pathHiddenHeader = [
    PATH_HOME
];
const isHiddenHeader = (path)=>{
    return pathHiddenHeader.every((_path)=>_path === path) ? "hidden" : "flex";
};
const isShowInput = ()=>{
    return async (dispatch, getState)=>{
        console.log("isShowInput", getState());
        return getState();
    // const currentState= getState().example;
    // console.log(currentState) 
    };
};
const stepArray = [
    1,
    2,
    3
];
const INPUT_NUMBER_TYPE = "number";
const INPUT_SELECT_TYPE = "select";
const INPUT_STRING_TYPE = "string";
const INPUT_DATE_TYPE = "date";
const APPLY = "\xc1p dụng";
const SELECT_PACKAGE = "Chọn g\xf3i n\xe0y";
const BUY_ONLINE = "Mua trực tuyến";
const COUNTINUE = "Tiếp tục";
const AGREE = "Đồng \xfd";
const BUY_NOW = "Mua ngay";
const isObjectEmpty = (object)=>{
    return lodash_default().isEmpty(object);
};


/***/ }),

/***/ 227:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HY": () => (/* binding */ backStep),
/* harmony export */   "Hx": () => (/* binding */ turnOnInput),
/* harmony export */   "Rv": () => (/* binding */ getInputStatus),
/* harmony export */   "TO": () => (/* binding */ getStep),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "aK": () => (/* binding */ getMaxStep),
/* harmony export */   "cQ": () => (/* binding */ turnOffInput),
/* harmony export */   "fx": () => (/* binding */ getStep0data),
/* harmony export */   "sl": () => (/* binding */ selectInsuraneBuy),
/* harmony export */   "v7": () => (/* binding */ getInputData),
/* harmony export */   "zF": () => (/* binding */ nextStep)
/* harmony export */ });
/* unused harmony exports initialState, getTypeInsurance, resetStepData */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(668);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    step: 0,
    stepData: {},
    contractId: "",
    step_1: {},
    step_2: {},
    step_3: {},
    type: null,
    step0data: {},
    maxStep: 3,
    isInput: false,
    inputData: {}
};
const buyInsurance = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "buyInsurance",
    initialState,
    reducers: {
        selectInsuraneBuy: (state, action)=>{
            state.type = action.payload.type;
            state.step0data = action.payload;
        },
        backStep: (state)=>{
            if (state.step === 0) {
                return;
            } else if (state.step >= 0 && state.step <= state.maxStep) {
                state.step--;
            }
        },
        nextStep: (state)=>{
            if (state.step === null) {
                state.step = 0;
            } else if (state.step >= 0 && state.step < state.maxStep) {
                state.step++;
            } else if (state.step === state.maxStep) {
                return;
            }
        },
        resetStepData: (state)=>{
            state.step = 0;
            state.stepData = null;
            state.type = null;
            state.step0data = {};
        },
        turnOnInput: (state, action)=>{
            state.isInput = true;
            state.inputData = action.payload;
        },
        turnOffInput: (state)=>{
            state.isInput = false;
        }
    }
});
// Selectors
const getStep = (state)=>state.buyInsurance.step;
const getTypeInsurance = (state)=>state.buyInsurance.type;
const getStep0data = (state)=>state.buyInsurance.step0data;
const getMaxStep = (state)=>state.buyInsurance.maxStep;
const getInputStatus = (state)=>state.buyInsurance.isInput;
const getInputData = (state)=>state.buyInsurance.inputData;
// Reducers and actions
const { selectInsuraneBuy , backStep , nextStep , resetStepData , turnOnInput , turnOffInput  } = buyInsurance.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (buyInsurance.reducer);


/***/ }),

/***/ 1338:
/***/ (() => {



/***/ })

};
;