
const Step3 = () => {
    return (
      <div>view step3</div>
    )
  }
  
  export default Step3