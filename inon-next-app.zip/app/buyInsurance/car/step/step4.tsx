import React from 'react'

const Step4 = () => {
  return (
    <div>Step4</div>
  )
}

export default Step4