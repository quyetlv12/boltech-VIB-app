import React from 'react'
import BannerStep0 from './BannerStep0'

const BuyInsuranceStep = () => {
  return (
   <BannerStep0/>
  )
}

export default BuyInsuranceStep